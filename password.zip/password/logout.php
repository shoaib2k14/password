<?php
 session_start();
 //phpinfo();
 //echo ini_get('session.save_path');
 /* echo '<pre>';
   var_dump($_SESSION);
 echo '</pre>'; */
 
 
 if($_REQUEST['key']==0){
	 unset($_SESSION['is_admin_login']);
     unset($_SESSION['aEmail']);
     unset($_SESSION['aRole']);
 }
 
 elseif($_REQUEST['key']==1){
	 unset($_SESSION['is_user_login']);
     unset($_SESSION['uEmail']);
 }
 
 else{
	 session_destroy();
	 
 }
 
 echo "<script> location.href='index.php'; </script>";
 
 
?>