<?php

include('../../dbConnection.php');

$market = $_REQUEST['market'];
$role = $_REQUEST['role'];
$server = $_REQUEST['server'];
$employee_id = $_REQUEST['employee_id'];

$msg = 0;


 $sql = "SELECT * from servers Where id = $server AND market_id = $market";
 $result = mysqli_query($conn , $sql);
 $row = mysqli_fetch_assoc($result);
 $host_name = $row['host_name'];
 $ip_address = $row['ip_address'];
 $server_password = $row['password'];
 
 


/************ For Pdf file creation **************/ 
try{
	$file_name = date('His-Ymd-').$employee_id.'.pdf';
	$directory = dirname(__FILE__, 3).'/User/public/file/'.$file_name;
	
	$password = rand(100000, 999999);

	require('../pdf/fpdf_protection.php');
	$pdf = new FPDF_Protection();
	$pdf->SetProtection(array('print'), $password); 
	$pdf->AddPage();
	$pdf->SetFont('Arial', 'B', 18);
	$pdf->Cell(100, 12, 'Servers Details', 0);
	$pdf->Ln();
	$pdf->SetFont('Arial', 'B', 12);
	
		$pdf->Cell(32,12, 'Host Name', 1);
		$pdf->Cell(32,12, 'Ip Address', 1);
		$pdf->Cell(32,12, 'Password', 1);
	
	$pdf->SetFont('Arial', '', 12);
	$pdf->Ln();
	
		$pdf->Cell(32,12, $host_name, 1);
		$pdf->Cell(32,12, $ip_address, 1);
		$pdf->Cell(32,12, $server_password, 1);
	
	//$pdf->Output();
	//$pdf->Output("D","sho.pdf");
	//$obj_pdf->Output($clts."-".$date."-".$time.'.pdf', 'I');
	$pdf->Output("F",$directory);
	
	
	
	$sql_u = "SELECT id FROM users WHERE employee_id= '$employee_id'";
	$result_u = $conn->query($sql_u);
	$row_u = $result_u->fetch_assoc();
	$uID = $row_u['id'];
	
	$sql_i = "INSERT INTO files (user_id, file, password) VALUES('$uID', '$file_name', '$password')";
	$conn->query($sql_i);
	
	$msg = 1;
}

catch(Exception $e){
    $msg = 0;
    //echo 'Message: ' .$e->getMessage();
}




/************ For Text and Zip file creation **************/ 
/*
 if(mysqli_num_rows($result)==1){
	 
	$myfile = fopen($employee_id.".txt", "w") or die("Unable to open file!");
	$txt = "Host Name: ".$host_name.", Ip Address: ".$ip_address.", Password: ".$password;
	fwrite($myfile, $txt);
	fclose($myfile);
	
	
	
	//$rootDir = realpath($_SERVER["DOCUMENT_ROOT"]);
	//echo __FILE__;
	$input= dirname(__FILE__).'/'.$employee_id.'.txt';
	//$input= dirname(__FILE__).'/shoaib.pdf';
	
	$zip_name = date('His-Ymd-').$employee_id.'.zip';
	$zip = new ZipArchive;
	$res = $zip->open($zip_name, ZipArchive::CREATE);
	//$res = $zip->setPassword($passcode);
	
	if($res === TRUE){
		$zip->addFile($input);
		$zip->close();
		unlink($employee_id.'.txt');
		$msg = 1;
		
		$sql_u = "SELECT id FROM users WHERE employee_id= '$employee_id'";
	    $result_u = $conn->query($sql_u);
	    $row_u = $result_u->fetch_assoc();
	    $uID = $row_u['id'];
		
		$sql_i = "INSERT INTO files (user_id, file, password) VALUES('$uID', '$zip_name', '$passcode')";
		$conn->query($sql_i);
	}
	else{
		$msg = 0;
	}
}
*/

?>

<?php
if($msg == 1){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<i class="fa fa-check-square success_Msg"></i>
					<h5 class="delete_class status_header">Pdf file has sent on your mail</h5>
					<p class="status_content">Thanks</p>
					<button type="button" class="btn btn-secondary float-right" onclick="reload()">Close</button>
				</div>
			</div>
		</div>
	</div>
<?php } ?>



<?php
if($msg == 0){?>
	<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
			        <img class="failed_Msg" src="images/sent.png">
			        <!--<i class="fa fa-info-circle failed_Msg"></i>-->
					<h5 class="delete_class status_header">Please try after some time</h5>
					<p class="status_content">Thanks</p>
					<button type="button" class="btn btn-secondary float-right" class="close" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
<?php } ?>