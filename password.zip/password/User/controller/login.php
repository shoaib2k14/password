<?php

include('../dbConnection.php');

   if(!isset($_SESSION['is_user_login'])){
	  if(isset($_REQUEST['uEmail'])){
		$uEmail = mysqli_real_escape_string($conn,trim($_REQUEST['uEmail']));
		$uPassword = mysqli_real_escape_string($conn,trim($_REQUEST['uPassword']));
		$sql = "SELECT email, password, f_name, l_name FROM users WHERE email='".$uEmail."' AND password='".$uPassword."' limit 1";
		$result = $conn->query($sql);
		if($result->num_rows == 1){
		  
		  $_SESSION['is_user_login'] = true;
		  $_SESSION['uEmail'] = $uEmail;
		  
		  // Redirecting to RequesterProfile page on Correct Email and Pass
		  echo "<script> location.href='dashboard.php'; </script>";
		  exit;
		} else {
		  $msg = '<div class="alert alert-warning mt-2" role="alert"> Enter Valid Email and Password </div>';
		}
	  }
	} else {
	  echo "<script> location.href='index.php'; </script>";
    }

?>