<?php
include('../../dbConnection.php');

$uEmail = $_SESSION['uEmail'];

$user_id=$_POST['id'];


$sql_market = "SELECT id,market FROM markets WHERE status = 1";
  $result_market = $conn->query($sql_market);
	
$sql_role = "SELECT id,role FROM roles WHERE status = 1";
  $result_role = $conn->query($sql_role);
	
$sql_emp = "SELECT employee_id, id FROM users WHERE id = $user_id";
  $result_emp = $conn->query($sql_emp);
  $row_emp = $result_emp->fetch_assoc();
  $user_id = $row_emp['id'];
  
?>

<div class="modal" id="getRoleRequestModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Request For New Role</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
     <!-- Modal Header end-->
	 
	 
     <!-- Modal body -->
      <div class="modal-body">
	     <form action="" method="POST" id="roleRequestForm">
			<div class="form-group">
			  <label>Employee Id</label>
			  <input type="hidden" class="form-control" name="id" value="<?php echo $row_emp['id']; ?>" readonly>
			  <input type="text" class="form-control" name="employee_id" value="<?php echo $row_emp['employee_id']; ?>" readonly>
			</div>
			<div class="form-group">  
			  <label>Select Market</label>
			  <select class="form-control" name="market">
				<option value="" disabled selected>Select Market</option>
				  <?php while($row_market = $result_market->fetch_assoc()){ ?>  
					<option value="<?php echo $row_market['id']; ?>"> <?php echo $row_market['market']; ?> </option>  
				  <?php }?>
			  </select>
			</div>
			<div class="form-group">
			  <label>Select Role</label>
			  <select class="form-control" name="role" onchange="getSendRRButton()">
				<option value="" disabled selected>Select Role</option>
				  <?php while($row_role = $result_role->fetch_assoc()){ ?>  
					<option value="<?php echo $row_role['id']; ?>"> <?php echo $row_role['role']; ?> </option>  
				  <?php }?>
			  </select>
			</div>
		  </form>
      </div> 
	  <!-- Modal body end-->
	  
	  <!-- Modal Footer -->
	  <div class="modal-footer float-right">
	     <button type="button" class="btn btn-primary" id="sendRRModal" onclick="sendRoleRequestModal()">Request</button>
	     <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
	  </div>
	  <!-- Modal Footer end-->
      
    </div>
   </div>
 </div>