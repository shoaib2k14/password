<?php
include('../../dbConnection.php');

$role_id = $_POST['role'];
//$market=$_POST['market'];

$sql = "SELECT DISTINCT servers.host_name, servers.id FROM servers,connects WHERE connects.role_id = $role_id AND connects.server_id = servers.id";   
	$result = $conn->query($sql);	
?>

 <label for="server">Select Server</label>
 <select class="item inn form-control" name="server" onchange="getServerUser(this.value)"> 
	  <option value="" disabled selected>Select Server</option> 
		<?php 
		  while($row = mysqli_fetch_array($result)) { ?> 
			  <option value="<?php echo $row['id']; ?>"><?php echo $row['host_name']; ?></option>
	   <?php } ?>				 
 </select>