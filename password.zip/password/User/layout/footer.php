        <div id="loaderImg"> 
          <img src="images/sLoader.gif">
       </div>
	  
	  
	  </div>
     </div>
    </div>

	<script src="public/js/common/jquery.js"></script>
	<script src="public/js/common/popper.min.js"></script>
	<script src="public/js/common/bootstrap.min.js"></script>
	<script src="public/js/common/perfect-scrollbar.jquery.min.js"></script>
	<script src="public/js/common/waves.js"></script>
	<script src="public/js/common/sidebarmenu.js"></script>
	<script src="public/js/common/custom.min.js"></script>
	<script src="public/js/common/jquery.dataTables.min.js"></script>
	<script src="public/js/common/dataTables.buttons.min.js"></script>
	<script src="public/js/common/sweetalert2.min.js"></script>

	<script>
	   $(function () {
			var table = $('.data-table').DataTable({
				processing: true,
				//serverSide: true,
			});
	   });
	</script>
	

<?php
 if(PAGE == 'role'){?>
 
	<script>
	    $('#sendRRModal').hide();
		
		function getDetails(role,market) {
			 //alert(role + market);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getPasswordRequestModal.php',
				 type:'POST',
				 data:{
					   role:role,
					   market:market,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#myModal').modal('show');
				 }
			 });
		 }
		 
		 
		function viweServer(id,role,market) {
			 //alert(id + role + market);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/viewServerModal.php',
				 type:'POST',
				 data:{
					   id:id,
					   role:role,
					   market:market,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#viewServerModal').modal('show');
				 }
			 });
		 }
		 
		 function getRoleRequestModal(id) {
			 //alert(id);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getRoleRequestModal.php',
				 type:'POST',
				 data:{
					   id:id,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#getRoleRequestModal').modal('show');
				 }
			 });
		 }
		 
		 function sendRoleRequestModal() {
			 //alert(id);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/sendroleRequestModal.php',
				 type:'POST',
				 data:$('#roleRequestForm').serialize(),
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#alertMsg').html(result);
					 $('#getRoleRequestModal').modal('hide');
					 $('#successMsgModal').modal('show');
				 }
			 });
		 }
		 
		 function getSendRRButton(){
			 $('#sendRRModal').show();
		 }
		 
	 </script>
	 
<?php } ?>





<?php
 if(PAGE == 'requested'){?>
   
   <script>
        $('#sendRRModal').hide();
		
		function getDetails(role,market) {
			 //alert(role + market);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getPasswordRequestModal.php',
				 type:'POST',
				 data:{
					   role:role,
					   market:market,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#myModal').modal('show');
				 }
			 });
		 }
		 
		 
		function viweServer(id,role,market) {
			 //alert(id + role + market);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/viewServerModal.php',
				 type:'POST',
				 data:{
					   id:id,
					   role:role,
					   market:market,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#viewServerModal').modal('show');
				 }
			 });
		 }
		 
		 function getRoleRequestModal(id) {
			 //alert(id);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getRoleRequestModal.php',
				 type:'POST',
				 data:{
					   id:id,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getPasswordRequestModal').html(result);
					 $('#getRoleRequestModal').modal('show');
				 }
			 });
		 }
		 
		 function sendRoleRequestModal() {
			 //alert(id);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/sendroleRequestModal.php',
				 type:'POST',
				 data:$('#roleRequestForm').serialize(),
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#alertMsg').html(result);
					 $('#getRoleRequestModal').modal('hide');
					 $('#successMsgModal').modal('show');
				 }
			 });
		 }
		 
		 function getSendRRButton(){
			 $('#sendRRModal').show();
		 }
		 
	</script>
 
<?php } ?>




<?php
 if(PAGE == 'getPassword'){?>
   
   <script>
       function openModal() {
			 $('#requestModal').modal('show');
			 $('#myModal').modal('hide');
			
		 }
		 


		 function getRole(market) {
			 //alert(market);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getRoleModal.php',
				 type:'POST',
				 data:{
					   market:market,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#GetRole').html(result);
				 }
			 });
		 }
		 
		 
		 function getServer(role) {
			 //alert(role);
			 $('#loaderImg').show();
			 $.ajax({
				 url:'modal/getServerModal.php',
				 type:'POST',
				 data:{
					   role:role,
					 },
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#GetServer').html(result);
				 }
			 });
		 }
		 
		 function getReqButton(server) {
			 //alert(server);
			 $("#sendReqButton").show();
		 }
		 
		 
		 function sendFile() {
			 //alert('hello');
			 $('#loaderImg').show();
			 $.ajax({
				 url:'controller/sendMail.php',
				 type:'POST',
				 data:$('#addFormData').serialize(),
				 success:function(result){
					 $('#loaderImg').hide();
					 $('#getStatusModal').html(result);
					 $('#requestModal').modal('hide');
					 $("#sendReqButton").hide();
					 $("#GetRole").hide();
					 $("#GetServer").hide();
					 $('#successMsgModal').modal('show');
				}
			 });
		   }
		   
		   
		 function reload(){
			 $('#requestModal').modal('hide');
			 $("#sendReqButton").hide();
			 $("#GetRole").hide();
			 $("#GetServer").hide();
			 $('#successMsgModal').modal('hide');
			 location.reload();
		  }
		  
		 $(document).ready(function(){
			//$('#productTable').DataTable();
			$("#sendReqButton").hide();

		 });
	</script>

<?php } ?>



<?php
 if(PAGE == 'profile'){?>
 
    <script>
		  var view = document.getElementById("profile_view");
		  var edit = document.getElementById("profile_edit");
		  view.style.display = "none";
		  edit.style.display = "none";
		  
		function show() {
		  edit.style.display = "none";
		  view.style.display = "block";
		}
		
		function hide() {
		  edit.style.display = "none";
		  view.style.display = "none";
		}
		
		function edits() {
		  view.style.display = "none";
		  edit.style.display = "block";
		}
   </script>

 <?php } ?>
	

 </body>
</html>