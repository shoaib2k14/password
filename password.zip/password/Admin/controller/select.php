<?php

include('../dbConnection.php');

if(!isset($_SESSION['is_admin_login'])){
	echo "<script> location.href='index.php'; </script>";
 }
 
 
 
$aMarket = $_SESSION['aMarket'];
$aRole = $_SESSION['aRole'];


if($aRole != 0){
	
	$admin = "Admin!";
	
	if($table_name == 'dashboard'){
		
		// I'm India so my timezone is Asia/Calcutta
			 date_default_timezone_set('Asia/Calcutta');

		 // 24-hour format of an hour without leading zeros (0 through 23)
			 $Hour = date('G');

			if ( $Hour >= 5 && $Hour <= 11 ) {
				$grettings = "Good Morning";
			} else if ( $Hour >= 12 && $Hour <= 17 ) {
				$grettings = "Good Afternoon";
			} else if ( $Hour >= 15 || $Hour <= 4 ) {
				$grettings = "Good Evening";
			}
			
			
		  $sql_requested = "SELECT count(*) as requested FROM role_requests where market_id = $aMarket";
			 $result_requested = $conn->query($sql_requested);
			 $row_requested = mysqli_fetch_array($result_requested);
			 $requested_roles = $row_requested['requested'];

	      $sql_connection = "SELECT count(*) as connection FROM connects where market_id = $aMarket";
			 $result_connection = $conn->query($sql_connection);
			 $row_connection = mysqli_fetch_array($result_connection);
			 $all_connections = $row_connection['connection'];

	     $sql_users = "SELECT count(*) as users FROM users where market_id = $aMarket";
			 $result_users = $conn->query($sql_users);
			 $row_users = mysqli_fetch_array($result_users);
			 $all_users = $row_users['users'];
			 
		
		$sql_roles = "SELECT count(*) as roles FROM roles where market_id = $aMarket";
			 $result_roles = $conn->query($sql_roles);
			 $row_roles = mysqli_fetch_array($result_roles);
			 $all_roles = $row_roles['roles'];

	
	}
	
	
	if($table_name == 'users'){
		//$sql = "select * from users,user_profiles,markets,departments,positions WHERE users.id = user_profiles.user_id AND user_profiles.market_id = markets.id AND user_profiles.department_id = departments.id AND user_profiles.position_id = positions.id";
		
		$sql = "select *,users.id AS uId,users.status AS uStatus, users.created_at AS uCreatedAt from users,markets WHERE users.market_id = markets.id AND users.market_id = $aMarket ORDER BY users.id Desc";
	}
	
	if($table_name == 'admins'){
		$sql = "select *, admins.id, admins.status, admins.created_at from admins,markets WHERE admins.market_id = markets.id AND admins.role = 1 AND admins.market_id = $aMarket";
	}

	if($table_name == 'roles'){
		$sql = "select * from roles WHERE market_id = $aMarket";
	}
    
	if($table_name == 'markets'){
		$sql = "select * from markets WHERE id = $aMarket";
	}
	
	if($table_name == 'servers'){
		$sql = "select *,servers.id AS id, servers.status AS status, servers.created_at AS created_at  from servers,server_owners,markets WHERE server_owners.id = servers.owner_id AND servers.market_id = markets.id AND servers.market_id = $aMarket";
	}
	
	if($table_name == 'server_owners'){
		$sql = "select * from server_owners WHERE market_id = $aMarket";
	}
	
	if($table_name == 'connects'){
		$sql = "select * from connects WHERE market_id = $aMarket";
	}
	
	if($table_name == 'role_requests'){
		$sql = "select * from role_requests,users,roles,markets WHERE role_requests.user_id = users.id AND role_requests.role_id = roles.id AND role_requests.market_id = markets.id AND role_requests.market_id = $aMarket";
	}
}





else{
	$admin = "Super Admin!";
	
	if($table_name == 'dashboard'){
		
		// I'm India so my timezone is Asia/Calcutta
			 date_default_timezone_set('Asia/Calcutta');

		 // 24-hour format of an hour without leading zeros (0 through 23)
			 $Hour = date('G');

			if ( $Hour >= 5 && $Hour <= 11 ) {
				$grettings = "Good Morning";
			} else if ( $Hour >= 12 && $Hour <= 17 ) {
				$grettings = "Good Afternoon";
			} else if ( $Hour >= 15 || $Hour <= 4 ) {
				$grettings = "Good Evening";
			}
			
			$sql_requested = "SELECT count(*) as requested FROM role_requests";
			 $result_requested = $conn->query($sql_requested);
			 $row_requested = mysqli_fetch_array($result_requested);
			 $requested_roles = $row_requested['requested'];

	      $sql_connection = "SELECT count(*) as connection FROM connects";
			 $result_connection = $conn->query($sql_connection);
			 $row_connection = mysqli_fetch_array($result_connection);
			 $all_connections = $row_connection['connection'];

	     $sql_users = "SELECT count(*) as users FROM users";
			 $result_users = $conn->query($sql_users);
			 $row_users = mysqli_fetch_array($result_users);
			 $all_users = $row_users['users'];
			 
		
		$sql_roles = "SELECT count(*) as roles FROM roles";
			 $result_roles = $conn->query($sql_roles);
			 $row_roles = mysqli_fetch_array($result_roles);
			 $all_roles = $row_roles['roles'];
	
	}
	
	if($table_name == 'users'){
		//$sql = "select * from users,user_profiles,markets,departments,positions WHERE users.id = user_profiles.user_id AND user_profiles.market_id = markets.id AND user_profiles.department_id = departments.id AND user_profiles.position_id = positions.id";
		
		$sql = "select *,users.id AS uId,users.status AS uStatus, users.created_at AS uCreatedAt from users,markets WHERE users.market_id = markets.id ORDER BY users.id Desc";
	}
	
	if($table_name == 'admins'){
		$sql = "select *, admins.id, admins.status, admins.created_at from admins,markets WHERE admins.market_id = markets.id AND admins.role = 1";
	}

	if($table_name == 'roles'){
		$sql = "select * from roles";
	}
    
	if($table_name == 'markets'){
		$sql = "select * from markets";
	}
	
	if($table_name == 'servers'){
		$sql = "select *,servers.id AS id, servers.status AS status, servers.created_at AS created_at  from servers,server_owners,markets WHERE server_owners.id = servers.owner_id AND servers.market_id = markets.id";
	}
	
	if($table_name == 'server_owners'){
		$sql = "select * from server_owners";
	}
	
	if($table_name == 'connects'){
		$sql = "select * from connects";
	}
	
	if($table_name == 'role_requests'){
		$sql = "select * from role_requests,users,roles,markets WHERE role_requests.user_id = users.id AND role_requests.role_id = roles.id AND role_requests.market_id = markets.id";
	}
}


   


/*** For oracle ***/
	//$result = oci_parse($connection, $sql);
	//oci_execute($result);

/*** For mysql ***/
  if($table_name != 'dashboard'){
	$result = mysqli_query($conn,$sql);
  }
	//$count = mysqli_num_rows($result);
	
	
 

?>