<?php

$modalName = "editModal";

include('../controller/modal.php');

?>


<?php
if($key == 'editAdmin'){?>
	<div class="modal fade delete-modal" id="editFormModal">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Edit Admin</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="editFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="editAdmin">
				<input type="hidden" class="form-control" type="text" name="id" value="<?php if(isset($data['id'])) {echo $data['id']; }?>">
				<div class="row formtype">
					<div class="col-md-6">
						<div class="form-group">
							<label>First Name</label>
							<input class="form-control" type="text" name="f_name" value="<?php if(isset($data['f_name'])) {echo $data['f_name']; }?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Last Name</label>
							<input class="form-control" type="text" name="l_name" value="<?php if(isset($data['l_name'])) {echo $data['l_name']; }?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" type="email" name="email" value="<?php if(isset($data['email'])) {echo $data['email']; }?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Mobile Number</label>
							<input class="form-control" type="number" name="mobile" value="<?php if(isset($data['mobile'])) {echo $data['mobile']; }?>">
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						  <select class="form-control" name="status">
							  <option value="1" <?php if($data['status']==1) { echo "selected"; } ?> >Active</option>
							  <option value="0" <?php if($data['status']==0) { echo "selected"; } ?> >Inactive</option>
						 </select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="updateOnDB('editAdmin')">Edit</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>





<?php
if($key == 'editRole'){?>
	<div class="modal fade delete-modal" id="editFormModal">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Edit Role</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="editFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="editRole">
				<input type="hidden" class="form-control" type="text" name="id" value="<?php if(isset($data['id'])) {echo $data['id']; }?>">
				<div class="row formtype">
					<div class="col-md-12">
						<div class="form-group">
							<label>Role</label>
							<input class="form-control" type="text" name="role" value="<?php if(isset($data['role'])) {echo $data['role']; }?>">
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						 <select class="form-control" name="status">
							  <option value="1" <?php if($data['status']==1) { echo "selected"; } ?> >Active</option>
							  <option value="0" <?php if($data['status']==0) { echo "selected"; } ?> >Inactive</option>
						 </select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="updateOnDB('editRole')">Edit</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>






<?php
if($key == 'editMarket'){?>
	<div class="modal fade delete-modal" id="editFormModal">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Edit Market</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="editFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="editMarket">
				<input type="hidden" class="form-control" type="text" name="id" value="<?php if(isset($data['id'])) {echo $data['id']; }?>">
				<div class="row formtype">
					<div class="col-md-12">
						<div class="form-group">
							<label>Market</label>
							<input class="form-control" type="text" name="market" value="<?php if(isset($data['market'])) {echo $data['market']; }?>">
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						<select class="form-control" name="status">
							  <option value="1" <?php if($data['status']==1) { echo "selected"; } ?> >Active</option>
							  <option value="0" <?php if($data['status']==0) { echo "selected"; } ?> >Inactive</option>
						</select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="updateOnDB('editMarket')">Edit</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>





<?php
if($key == 'editOwner'){?>
	<div class="modal fade delete-modal" id="editFormModal">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Edit Owner</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="editFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="editOwner">
				<input type="hidden" class="form-control" type="text" name="id" value="<?php if(isset($data['id'])) {echo $data['id']; }?>">
				<div class="row formtype">
					<div class="col-md-12">
						<div class="form-group">
							<label>Owner</label>
							<input class="form-control" type="text" name="owner" value="<?php if(isset($data['owner'])) {echo $data['owner']; }?>">
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" type="email" name="email" value="<?php if(isset($data['email'])) {echo $data['email']; }?>">
						</div>
					</div>
					<div class="col-md-12">
					  <div class="form-group">
						<label>Status</label>
						<select class="form-control" name="status">
							  <option value="1" <?php if($data['status']==1) { echo "selected"; } ?> >Active</option>
							  <option value="0" <?php if($data['status']==0) { echo "selected"; } ?> >Inactive</option>
						 </select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="updateOnDB('editOwner')">Edit</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>



<?php
if($key == 'editServer'){
	
	$sql_owner = "SELECT id,owner FROM server_owners WHERE status = 1 ORDER BY owner";
	$result_owner = $conn->query($sql_owner);
	
	?>
	<div class="modal fade delete-modal" id="editFormModal">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Edit Server</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="editFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="editServer">
				<input type="hidden" class="form-control" type="text" name="id" value="<?php if(isset($data['id'])) {echo $data['id']; }?>">
				<div class="row formtype">
				    <div class="col-md-6">
						<div class="form-group">
							<label>Select Owner</label>
							<select class="form-control" name="owner">
								<option value="" disabled selected>Select Owner</option>
								  <?php 
								   while($oRow=mysqli_fetch_assoc($oResult)){?>
                                        <option value="<?php echo $oRow['id'];?>" <?php if($oRow['id']==$data['owner_id']) { echo "selected"; } ?>><?php echo $oRow['owner'];?></option> 
								  <?php }?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>User</label>
							<input class="form-control" type="text" name="user" value="<?php if(isset($data['user'])) {echo $data['user']; }?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Host</label>
							<input class="form-control" type="text" name="host" value="<?php if(isset($data['host_name'])) {echo $data['host_name']; }?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Ip</label>
							<input class="form-control" type="text" name="ip" value="<?php if(isset($data['ip_address'])) {echo $data['ip_address']; }?>">
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Os Type</label>
						<select class="form-control" name="os_type">
							  <option value="windows" <?php if($data['os_type']=='windows') { echo "selected"; } ?> >Windows</option>
							  <option value="linux" <?php if($data['os_type']=='linux') { echo "selected"; } ?> >Linux</option>
						 </select>
					  </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Password</label>
							<input class="form-control" type="password" name="password" value="<?php if(isset($data['id'])) {echo $data['id']; }?>">
						</div>
					</div>
					<div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						<select class="form-control" name="status">
							  <option value="1" <?php if($data['status']==1) { echo "selected"; } ?> >Active</option>
							  <option value="0" <?php if($data['status']==0) { echo "selected"; } ?> >Inactive</option>
						</select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="updateOnDB('editServer')">Edit</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>




<?php
if($key == 'editUser'){
	
	$mSql= "SELECT id,market FROM markets WHERE status = 1 ORDER BY market";
	$mResult = $conn->query($mSql);
	
	?>
	<div class="modal fade delete-modal" id="editFormModal">
	  <div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title">Edit User</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			<form id="editFormData">
				<input type="hidden" class="form-control" type="text" name="key" value="editUser">
				<input type="hidden" class="form-control" type="text" name="id" value="<?php if(isset($data['id'])) {echo $data['id']; }?>">
				<div class="row formtype">
				    <div class="col-md-12">
						<div class="form-group">
							<label>Select Market</label>
							<select class="form-control" name="market">
								<option value="" disabled selected>Select Market</option>
								  <?php 
								   while($mRow=mysqli_fetch_assoc($mResult)){?>
                                        <option value="<?php echo $mRow['id'];?>" <?php if($mRow['id']==$data['market_id']) { echo "selected"; } ?>><?php echo $mRow['market'];?></option> 
								  <?php }?>
							</select>
						</div>
					</div>
				    <div class="col-md-6">
						<div class="form-group">
							<label>Employee ID</label>
							<input class="form-control" type="text" name="employee_id" value="<?php if(isset($data['employee_id'])) {echo $data['employee_id']; }?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>First Name</label>
							<input class="form-control" type="text" name="f_name" value="<?php if(isset($data['f_name'])) {echo $data['f_name']; }?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Last Name</label>
							<input class="form-control" type="text" name="l_name" value="<?php if(isset($data['l_name'])) {echo $data['l_name']; }?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" type="email" name="email" value="<?php if(isset($data['email'])) {echo $data['email']; }?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>Mobile</label>
							<input class="form-control" type="text" name="mobile" value="<?php if(isset($data['mobile'])) {echo $data['mobile']; }?>">
						</div>
					</div>
				    <div class="col-md-6">
					  <div class="form-group">
						<label>Status</label>
						<select class="form-control" name="status">
							  <option value="1" <?php if($data['status']==1) { echo "selected"; } ?> >Active</option>
							  <option value="0" <?php if($data['status']==0) { echo "selected"; } ?> >Inactive</option>
						</select>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal-footer float-right">
				  <!--<input type="submit" class="btn btn-primary" value="Request"/>-->
				  <button type="submit" class="btn btn-primary" onclick="updateOnDB('editUser')">Edit</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			   </div>
			</form>
		  </div>
		  <!-- Modal body end-->
		</div>
	   </div>
	 </div>
<?php } ?>
