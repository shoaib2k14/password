<?php
$table_name = "servers";
$alert = "";

include('../dbConnection.php');
include('controller/select.php');

?>

<!DOCTYPE html>
<html lang="en">

<?php include("includes/head_link.php"); ?>

<body>
	<!-- Main Wrapper -->
	<div class="main-wrapper">
	
	   <?php include("includes/header.php"); ?>
	   
		<?php include("includes/sidebar.php"); ?>
		
		<!-- Page Wrapper -->
		<div class="page-wrapper">
			<div class="content container-fluid">
				<div class="page-header">
				    <div class="row align-items-center">
						<div class="col-12">
							<div class="mt-5">
								<h4 class="card-title float-left mt-2">Server</h4>
								<button class="btn btn-primary float-right veiwbutton " onclick="getForm('addServer')">Add Server</button>
							</div>
						</div>
					</div>
					
					<div class="row">
					  <div class="col-12">
					    <?php echo $alert; ?>
					  </div>
					</div>
					
					<div class="row">
					   <div class="col-sm-12">
                          <div class="card card-table">
							 <div class="card-header">
									<h4 class="card-title"></h4>
								</div>
							<div class="card-body booking_card">
								<div class="table-responsive">
									<table class="datatable table table-stripped table table-hover table-center mb-0">
										<thead>
											<tr>
												<th>User</th>
												<th>Host</th>
												<th>Ip</th>
												<th>Os Type</th>
												<th>Password</th>
												<th>Created_at</th>
												<th>Status</th>
												<th class="text-right">Actions</th>
											</tr>
										</thead>
										<tbody>
											<?php
												if(1){
													//while($row = oci_fetch($result)){
													while($row = mysqli_fetch_assoc($result)){ ?>
														
														 <tr>
															<td><?=$row["user"]?></td>
															
															<td><?=$row["host_name"]?></td>
															
															<td><?=$row["ip_address"]?></td>
															
															<td><?=$row["os_type"]?></td>
															
															<td><?=$row["password"]?></td>
															
															<td><?=$row["created_at"]?></td>
															
															<td>
															   <button type="submit" class="btn btn-success" onclick="updateStatusOnDB('<?=$row["id"]?>','dS','<?=$row["status"]?>')">
																   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
															  </button>
															</td>
															
															<td class="text-right">
																<div class="dropdown dropdown-action">
																  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
																   <i class="fa fa-ellipsis-v ellipse_color"></i>
																  </a>
																  
																  <div class="dropdown-menu dropdown-menu-right">
																      
																	  <a class="dropdown-item" href="#" onclick="editForm('<?=$row["id"]?>','dS')">
																	    <i class="fa fa-pencil m-r-5"></i> Edit
																	  </a>
																	  
																	  <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_asset" onclick="deleteAlert('<?=$row["id"]?>','<?=$row["host_name"]?>','dS')">
																	   <i class="fa fa-trash-o m-r-5"></i> Delete
																	  </a>
																  </div>
																  
															    </div>
															</td>
														</tr>
                                               <?php
												  }
                                                }
                                                else{
                                                 echo "No record found";
                                                }
                                              ?>
                                        </tbody>
									</table>
								</div>
							</div>
						</div>
                    </div>
				</div>
			</div>
		 </div>
		<!-- /Page Wrapper -->
	</div>
	<!-- /Main Wrapper -->
	
	
	<!-- Modal's -->
     <div id="getFormModal"></div>
     <div id="getStatusModal"></div>
    <!-- Model's -->
	
	
	<!-- jQuery -->
	<script>
		var element = document.getElementById("pwservers");
		   element.classList.add("active");
		   
		function myFunction(id) {
		   document.getElementById("primary_key_delete").setAttribute('value',id);
		}
    </script>
	
	<?php include("includes/script_link.php"); ?>
	<?php include("js/custom-js.php"); ?>
	
</body>

</html>