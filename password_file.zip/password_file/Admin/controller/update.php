<?php

include('../../dbConnection.php');

$msg = "";


if($_REQUEST['key']=='editAdmin'){
	
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['status'] == '')){
		
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$id = $_REQUEST['id'];
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$mobile = $_REQUEST['mobile'];
		$password = rand (100,999);
		$status = $_REQUEST['status'];
		//$created_at = "";
		
		$sql = "UPDATE admins SET f_name='$f_name', l_name='$l_name', email='$email', mobile='$mobile', password='$password', status='$status' WHERE id = $id ";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 



if($_REQUEST['key']=='editRole'){
	
	if(($_REQUEST['role'] == '') || ($_REQUEST['status'] == '')){
		
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$id = $_REQUEST['id'];
		$role = $_REQUEST['role'];
		$status = $_REQUEST['status'];
		//$created_at = "";
		
		
		$sql = "UPDATE roles SET role='$role',status = $status WHERE id = $id ";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"updated Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 


if($_REQUEST['key']=='editMarket'){
	
	if(($_REQUEST['market'] == '') || ($_REQUEST['status'] == '')){
		
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$id = $_REQUEST['id'];
		$market = $_REQUEST['market'];
		$status = $_REQUEST['status'];
		//$created_at = "";
		
		$sql = "UPDATE markets SET market='$market', status='$status' WHERE id = $id ";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 



if($_REQUEST['key']=='editOwner'){
	
	if(($_REQUEST['owner'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['status'] == '')){
		
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$id = $_REQUEST['id'];
		$owner = $_REQUEST['owner'];
		$email = $_REQUEST['email'];
		$status = $_REQUEST['status'];
		//$created_at = "";
		
		$sql = "UPDATE server_owners SET owner='$owner', email='$email', status='$status' WHERE id = $id ";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 


if($_REQUEST['key']=='editServer'){
	
	if(($_REQUEST['owner'] == '') || ($_REQUEST['user'] == '') || ($_REQUEST['host'] == '') || ($_REQUEST['os_type'] == '') || ($_REQUEST['ip'] == '') || ($_REQUEST['password'] == '') || ($_REQUEST['status'] == '')){
		 
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$id = $_REQUEST['id'];
		$owner_id = $_REQUEST['owner'];
		$user = $_REQUEST['user'];
		$host_name = $_REQUEST['host'];
		$ip_address = $_REQUEST['ip'];
		$os_type = $_REQUEST['os_type'];
		$password = $_REQUEST['password'];
		$status = $_REQUEST['status'];
		//$created_at = "";
		
		
		$sql = "UPDATE servers SET owner_id='$owner_id', user='$user', host_name='$host_name', ip_address='$ip_address', os_type='$os_type', password='$password', status='$status' WHERE id = $id ";
		
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 



if($_REQUEST['key']=='editUser'){
	
	if(($_REQUEST['employee_id'] == '') || ($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['market'] == '') || ($_REQUEST['status'] == '')){
		 
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$id = $_REQUEST['id'];
		$employee_id = $_REQUEST['employee_id'];
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$mobile = $_REQUEST['mobile'];
		$market_id = $_REQUEST['market'];
		$status = $_REQUEST['status'];
		$password = rand (100,999);
		//$created_at = "";
		
		
		$sql = "UPDATE users SET employee_id='$employee_id', market_id='$market_id', f_name='$f_name', l_name='$l_name', email='$email', mobile='$mobile', password='$password', status='$status' WHERE id = $id ";
		
		
		if($conn->query($sql) === TRUE) {
			$msg = 2; //"Inserted Successfully";
		} else {
		   
		   $msg = 3; //"Somthing Went Wrong";
		   
		   echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
} 





/*
if(isset($_REQUEST['update_user'])){
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['phone'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['company'] == '') || ($_REQUEST['department'] == '') || ($_REQUEST['position'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$phone = $_REQUEST['phone'];
		$mobile = $_REQUEST['mobile'];
		$company = $_REQUEST['company'];
		$department = $_REQUEST['department'];
		$position = $_REQUEST['position'];
		$date = $_REQUEST['date'];
		$status = 1;
		
		$sql = 'UPDATE PWUSERS SET FIRST_NAME=:f_name, LAST_NAME=:l_name, EMAIL=:email, PHONE=:phone, MOBILE=:mobile, COMPANY=:company, DEPARTMENT=:department, POSITION=:position, STATUS=:status WHERE ID=:id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		oci_bind_by_name($parse, ':f_name', $f_name);
		oci_bind_by_name($parse, ':l_name', $l_name);
		oci_bind_by_name($parse, ':email', $email);
		oci_bind_by_name($parse, ':phone', $phone);
		oci_bind_by_name($parse, ':mobile', $mobile);
		oci_bind_by_name($parse, ':company', $company);
		oci_bind_by_name($parse, ':department', $department);
		oci_bind_by_name($parse, ':position', $position);
		//oci_bind_by_name($parse, ':date', $date);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}

if(isset($_REQUEST['update_role'])){
	if(($_REQUEST['name'] == '') || ($_REQUEST['description'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$name = $_REQUEST['name'];
		$description = $_REQUEST['description'];
		$status = $_REQUEST['status'];
		
		$sql = 'UPDATE PWROLES SET NAME=:name, DESCRIPTION=:description, STATUS=:status WHERE ID=:id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		oci_bind_by_name($parse, ':name', $name);
		oci_bind_by_name($parse, ':description', $description);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}


if(isset($_REQUEST['update_groups'])){
	if(($_REQUEST['name'] == '') || ($_REQUEST['description'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$name = $_REQUEST['name'];
		$description = $_REQUEST['description'];
		$status = $_REQUEST['status'];
		
		$sql = 'UPDATE PWGROUPS SET NAME=:name, DESCRIPTION=:description, STATUS=:status WHERE ID=:id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		oci_bind_by_name($parse, ':name', $name);
		oci_bind_by_name($parse, ':description', $description);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}


if(isset($_REQUEST['update_connection'])){
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['phone'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['company'] == '') || ($_REQUEST['department'] == '') || ($_REQUEST['position'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$phone = $_REQUEST['phone'];
		$mobile = $_REQUEST['mobile'];
		$company = $_REQUEST['company'];
		$department = $_REQUEST['department'];
		$position = $_REQUEST['position'];
		$date = $_REQUEST['date'];
		$status = 1;
		
		$sql = 'UPDATE PWUSERS SET FIRST_NAME=:f_name, LAST_NAME=:l_name, EMAIL=:email, PHONE=:phone, MOBILE=:mobile, COMPANY=:company, DEPARTMENT=:department, POSITION=:position, STATUS=:status WHERE ID=:user_id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':user_id', $user_id);
		oci_bind_by_name($parse, ':f_name', $f_name);
		oci_bind_by_name($parse, ':l_name', $l_name);
		oci_bind_by_name($parse, ':email', $email);
		oci_bind_by_name($parse, ':phone', $phone);
		oci_bind_by_name($parse, ':mobile', $mobile);
		oci_bind_by_name($parse, ':company', $company);
		oci_bind_by_name($parse, ':department', $department);
		oci_bind_by_name($parse, ':position', $position);
		//oci_bind_by_name($parse, ':date', $date);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}

*/

?>




<?php
if($msg == 1){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Please fill all the fields</h3>
				<div class="m-t-20"> 
				    <!--<button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>-->
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>


<?php
if($msg == 2){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal" onclick="reload()">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Updated Successfully</h3>
				<div class="m-t-20"> 
				    <!--<button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>-->
					<a href="#" class="btn btn-white" data-dismiss="modal" onclick="reload()">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>


<?php
if($msg == 3){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Somthing Went Wrong</h3>
				<div class="m-t-20"> 
				    <!--<button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>-->
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>




<?php
if($msg == 4){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Undefined error please try after some time</h3>
				<div class="m-t-20"> 
				    <!--<button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>-->
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>
