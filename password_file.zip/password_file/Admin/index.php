<?php

include('../dbConnection.php');

if(!isset($_SESSION['is_admin_login'])){
	
  if(isset($_REQUEST['aEmail'])){
	  
    $aEmail = mysqli_real_escape_string($conn,trim($_REQUEST['aEmail']));
    $aPassword = mysqli_real_escape_string($conn,trim($_REQUEST['aPassword']));
    $sql = "SELECT email, password, role FROM admins WHERE email='".$aEmail."' AND password='".$aPassword."' AND status = 1 limit 1";
    $result = $conn->query($sql);
    if($result->num_rows == 1){
      
	  $row = mysqli_fetch_assoc($result);
	  
      $_SESSION['is_admin_login'] = true;
      $_SESSION['aEmail'] = $row['email'];
      $_SESSION['aRole'] = $row['role'];
	  
      // Redirecting to RequesterProfile page on Correct Email and Pass
      echo "<script> location.href='dashboard.php'; </script>";
      exit;
    } else {
      $msg = '<div class="alert alert-warning mt-2" role="alert"> Enter Valid Email and Password </div>';
    }
  }
} else {
  echo "<script> location.href='index.php'; </script>";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Admin Login</title>
  <link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="../User/assets/css/bootstrap.min.css">

  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="../User/assets/css/all.min.css">

  <style>
    .custom-margin {
         margin-top: 8vh;
      }
   </style>
  <title>Login</title>
</head>

<body>
  <div class="mb-3 text-center mt-5 mb-2">
    <!--<i class="fas fa-stethoscope"></i>-->
    <span></span>
  </div>
  <p class="text-center" style="font-size: 20px; margin-top: 10%;"><i class="fas fa-user-secret text-danger"></i><span> Admin Login </span></p>
  <div class="container-fluid mb-5">
    <div class="row justify-content-center">
      <div class="col-sm-6 col-md-4">
        <form action="" class="shadow-lg p-4" method="POST">
          <div class="form-group">
            <i class="fas fa-user"></i><label for="email" class="pl-2 font-weight-bold">Email</label><input type="email"
              class="form-control" placeholder="Email" name="aEmail">
            <!--Add text-white below if want text color white-->
            <small class="form-text">We'll never share your email with anyone else.</small>
          </div>
          <div class="form-group">
            <i class="fas fa-key"></i><label for="pass" class="pl-2 font-weight-bold">Password</label><input type="password"
              class="form-control" placeholder="Password" name="aPassword">
          </div>
          <button type="submit" class="btn btn-outline-danger mt-3 btn-block shadow-sm font-weight-bold">Login</button>
          <?php if(isset($msg)) {echo $msg; } ?>
        </form>
        
      </div>
    </div>
  </div>

  <!-- Boostrap JavaScript -->
  <script src="../User/assets/js/jquery.min.js"></script>
  <script src="../User/assets/js/popper.min.js"></script>
  <script src="../User/assets/js/bootstrap.min.js"></script>
  <script src="../User/assets/js/all.min.js"></script>
</body>

</html>