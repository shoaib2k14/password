<?php
$role=$_POST['role'];
$market=$_POST['market'];
?>

<div class="modal" id="myModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Request password of <?=$role;?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="">
		 <div class="form-group">
		     <label for="server">Select Server</label>
			 <select class="form-control" name="server" id="server">
			  <option value="1">Server-1</option>
			  <option value="2">Server-2</option>
			  <option value="3">Server-3</option>
			  <option value="4">Server-4</option>
			  <option value="5">Server-5</option>
			 </select>
		 </div>
		 <div class="form-group">
		     <label for="user">Select User</label>
			 <select class="form-control" name="user" id="user">
			  <option value="1">User-1</option>
			  <option value="2">User-2</option>
			  <option value="3">User-3</option>
			  <option value="4">User-4</option>
			  <option value="5">User-5</option>
			 </select>
		 </div>
		 <div class="modal-footer float-right">
		   <input type="submit" class="btn btn-primary" value="Request"/>
           <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
         </div>
		</form>
      </div>
    </div>
   </div>
 </div>