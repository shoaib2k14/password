<?php
$id=$_POST['id'];
$role=$_POST['role'];
$market=$_POST['market'];
?>

<style>
.card{
	box-shadow: inset 0 -3em 3em rgba(0, 0, 0, 0.1), 0 0 0 2px rgb(255, 255, 255),
    0.3em 0.3em 1em rgba(0, 0, 0, 0.3);
}
</style>

<div class="modal fade delete-modal" id="viewServerModal">
	<div class="modal-dialog modal-dialog-centered modal-lg">
	<div class="modal-content">

	  <!-- Modal Header -->
	  <div class="modal-header">
		<h4 class="modal-title"><?=$role;?></h4>
		<button type="button" class="close" data-dismiss="modal">&times;</button>
	  </div>

	  <!-- Modal body -->
	  <div class="row m-3">
		  <div class="col-sm-4 mb-4">
			  <div class="card">
				 <div class="text-white bg-info">
				   <div class="card-header">1</div>
				   <div class="card-body">
					 <h6 class="card-title">Server: </h6>
					 <p class="card-text">User:</p>
				   </div>
				 </div>
			  </div>
		   </div>
		   
		   <div class="col-sm-4 mb-4">
			  <div class="card">
				 <div class="text-white bg-info">
				   <div class="card-header">2</div>
				   <div class="card-body">
					 <h6 class="card-title">Server: </h6>
					 <p class="card-text">User:</p>
				   </div>
				 </div>
			  </div>
		   </div>
		   
		   <div class="col-sm-4 mb-4">
			  <div class="card">
				 <div class="text-white bg-info">
				   <div class="card-header">3</div>
				   <div class="card-body">
					 <h6 class="card-title">Server: </h6>
					 <p class="card-text">User:</p>
				   </div>
				 </div>
			  </div>
		   </div>
		   
		    <div class="col-sm-4 mb-4">
			  <div class="card">
				 <div class="text-white bg-info">
				   <div class="card-header">4</div>
				   <div class="card-body">
					 <h6 class="card-title">Server: </h6>
					 <p class="card-text">User:</p>
				   </div>
				 </div>
			  </div>
		   </div>
		</div>	
	  <!-- Modal body end-->	  
		
      <!-- Modal Footer -->		
	  <div class="modal-footer float-right">
		  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
	  </div>
	  <!-- Modal Footer end-->	
		
	 </div>
   </div>
</div>