<?php
define('TITLE', 'Get-Password');
define('PAGE', 'getPassword');


include('../dbConnection.php');
include('includes/header.php'); 


 if(isset($_SESSION['is_user_login'])){
     $uEmail = $_SESSION['uEmail'];
   
     $sql_user = "SELECT * FROM users where email = '{$uEmail}'";
	 $result_user = $conn->query($sql_user);
	 $row_user = $result_user->fetch_assoc();
	 $user_id = $row_user['id'];
 } 
 else {
   echo "<script> location.href='index.php'; </script>";
 }
 
?>

<div class="col-sm-8 mb-5">
  <div class="card mt-5 mx-5">
   <div class="card-header">Employee ID : <?php echo $row_user['employee_id']; ?></div>
   <div class="card-body">
	    <form id="addFormData">
		  <div class="form-group">
		     <input type="hidden" class="form-control" type="text" name="employee_id" value="<?php echo $row_user['employee_id']; ?>">
			 
		     <label for="server">Select Market</label>
			 <select class="form-control" name="market" id="market" onchange="getRole(this.value)"> 
				  <option value="" disabled selected>Select Market</option> 
				    <?php 
					  $mSql = "SELECT * FROM markets WHERE status = 1";   
					  $mResult = $conn->query($mSql);			    
					  while($mRow = mysqli_fetch_array($mResult)) { ?> 
						  <option value="<?php echo $mRow['id']; ?>"><?php echo $mRow['market']; ?></option>
				   <?php } ?>				 
			 </select>
			 
			 <div class="mt-3" id="GetRole"></div>
			 
			 <div class="mt-3" id="GetServer"></div>
			 
		  </div>
		 
		  <div class="modal-footer float-right">
		   <button type="button" class="btn btn-primary" onclick="sendFile(this.value)">Request</button>
           <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
         </div>
		</form>
     </div>
   </div>  
</div>

<div id="getStatusModal"></div>

<?php 
  include('includes/footer.php'); 
  $conn->close();
?>

<script>

 function getRole(market) {
	 //alert(market);
	 $.ajax({
		 url:'modal/getRoleModal.php',
		 type:'POST',
		 data:{
			   market:market,
			 },
		 success:function(result){
			 $('#GetRole').html(result);
			 $('#myModal').modal('show');
		 }
	 });
 }
 
 
 function getServer(role) {
	 //alert(role);
	 $.ajax({
		 url:'modal/getServerModal.php',
		 type:'POST',
		 data:{
			   role:role,
			 },
		 success:function(result){
			 $('#GetServer').html(result);
			 $('#myModal').modal('show');
		 }
	 });
 }
 
 
 function sendFile() {
	 //alert('hello');
	 $.ajax({
		 url:'controller/sendMail.php',
		 type:'POST',
		 data:$('#addFormData').serialize(),
		 success:function(result){
			 $('#getStatusModal').html(result);
			 $('#successMsgModal').modal('show');
		}
	 });
   }
</script>