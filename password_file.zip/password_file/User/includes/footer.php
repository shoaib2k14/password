<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/all.min.js"></script>
<script src="assets/js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" charset="utf8" src="assets/js/dataTables.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

</body>

</html>