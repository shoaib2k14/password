<?php
    //$zip = new ZipArchive();
    //$zip->setEncryptionName('test.txt', ZipArchive::EM_AES_256, 'test');

/*
	$zip = new ZipArchive;
	$res = $zip->open('test.zip', ZipArchive::CREATE);
	$zip->setPassword('123');
	
	if ($res === TRUE) {
		$zip->addFromString('test.txt', 'shoaib');
		$zip->setEncryptionName('test.txt', ZipArchive::EM_AES_256, 'passw0rd');
		$zip->close();
		echo 'ok';
	} else {
		echo 'failed';
	}
	
*/	
	$output="test.zip";
	
	$input="test.txt";
	
	$zip = new ZipArchive;
	
	$zip->open($output, ZipArchive::CREATE);
	$res = $zip->setPassword('123');
	
	if($res === TRUE){
		$zip->addFile($input);
		$zip->close();
		echo 'ok';
	}
	else {
		echo 'failed';
	}
	

?>