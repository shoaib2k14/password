<?php
$market = $_REQUEST['market'];
$role = $_REQUEST['role'];
$server = $_REQUEST['server'];
$employee_id = $_REQUEST['employee_id'];

?>



<?php
	$myfile = fopen($employee_id.".txt", "w") or die("Unable to open file!");
	$txt = "Mickey Mouse\n";
	fwrite($myfile, $txt);
	$txt = "Minnie Mouse\n";
	fwrite($myfile, $txt);
	fclose($myfile);
?>

<?php

    $rootDir = realpath($_SERVER["DOCUMENT_ROOT"]);
	
	//echo $rootDir;
	
	//echo __FILE__;
	
	//echo dirname(__FILE__).'/'.$employee_id.'.txt';
	
	//exit;

    $output= $employee_id.'.zip';
	
	$input= dirname(__FILE__).'/'.$employee_id.'.txt';;
	
	$zip = new ZipArchive;
	
	$zip->open($output, ZipArchive::CREATE);
	$res = $zip->setPassword('123');
	
	if($res === TRUE){
		$zip->addFile($input);
		$zip->close();
		echo 'ok';
	}
	else {
		echo 'failed';
	}
	

?>



<div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<h5 class="delete_class">One Zip file has sent on your mail</h5>
				<p>Thanks</p>
			</div>
		</div>
	</div>
</div>