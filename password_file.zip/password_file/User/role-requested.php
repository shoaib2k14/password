<?php
define('TITLE', 'Role');
define('PAGE', 'requested');

include('../dbConnection.php');
include('includes/header.php'); 

 if(isset($_SESSION['is_user_login'])){
	  $uEmail = $_SESSION['uEmail'];
	  $sql_user_id = "SELECT id, email FROM users WHERE email='".$uEmail."' limit 1";
	  $result_user_id = $conn->query($sql_user_id);
	  $row_user_id = $result_user_id->fetch_assoc();
	  $uID = $row_user_id['id'];
 } else {
  echo "<script> location.href='index.php'; </script>";
 }
?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.3/datatables.min.css"/>
  <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.3/datatables.min.js"></script>

<div class="col-sm-9 col-md-10 mt-5">
 <p class="p-2 mb-4 h2">Requested Role</p>
  <?php 
 $sql = "SELECT role_requests.is_approved, role_requests.is_pending, role_requests.is_declined, role_requests.created_at, role_requests.description, markets.market as market, roles.role as role FROM role_requests, roles, markets where role_requests.user_id = {$uID} and role_requests.role_id = roles.id and role_requests.market_id = markets.id ";
 
 $result = $conn->query($sql);
 if($result->num_rows > 0){ ?>
 
 <table class="table table-hovered table-striped" id="productTable">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Role</th>
      <th scope="col">Market</th>
      <th scope="col">Requested Date</th>
      <th scope="col">Status</th>
      <th scope="col">Description</th>
    </tr>
  </thead>
  <tbody>
  <?php $count = 0; 
        while($row = $result->fetch_assoc()){; ?>
   <tr>
    <th scope="row"><?php echo ++$count; ?></th>
    <td><?php echo $row["role"]; ?></td>
    <td><?php echo $row["market"]; ?></td>
    <td><?php echo $row["created_at"]; ?></td>
    <td><?php if($row["is_approved"] == 1){ echo "Approved"; } if($row["is_declined"] == 1){echo "Rejected";} else {echo "Pending";}?></td>
    <td><?php echo $row["description"]; ?></td>
   </tr>
   <?php } ?>
  </tbody> 
 </table>
  <?php } else { echo "0 Result"; } ?>
  
</div>
</div>
<a class="btn btn-danger box" href="role-request.php"><i class="fas fa-plus fa-2x"></i></a>
</div>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script type="text/javascript">
 $(document).ready(function(){
	$('#productTable').DataTable();
 });
 
</script>
<?php
include('includes/footer.php'); 
?>