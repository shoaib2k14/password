<?php

include('../../dbConnection.php');

$msg = "";


	
	if(($_REQUEST['server'] == '') || ($_REQUEST['password'] == '')){
		
		$msg = 1; //"Please fill all the fields";
	}
	else{
		$server_id = $_REQUEST['server'];
		$password = trim($_REQUEST['password']);
		
		$sql = "UPDATE servers SET password='$password' WHERE id = $server_id ";
		
		if($conn->query($sql) === TRUE) {
		   $msg = 2; //"Inserted Successfully";
		} else {
		   $msg = 3; //"Somthing Went Wrong";
		   
		   //echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	
	}
 




?>




<?php
if($msg == 1){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Please fill all the fields</h3>
				<div class="m-t-20"> 
				    <!--<button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>-->
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>


<?php
if($msg == 2){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal" onclick="reload()">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Updated Successfully</h3>
				<div class="m-t-20"> 
				    <!--<button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>-->
					<a href="#" class="btn btn-white" data-dismiss="modal" onclick="reload()">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>


<?php
if($msg == 3){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Somthing Went Wrong</h3>
				<div class="m-t-20"> 
				    <!--<button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>-->
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>




<?php
if($msg == 4){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Undefined error please try after some time</h3>
				<div class="m-t-20"> 
				    <!--<button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>-->
					<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>
