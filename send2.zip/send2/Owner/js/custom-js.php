<script>
   
   function getForm(key) {
	 //alert(key);
	 $.ajax({
		 url:'modal/addModal.php',
		 type:'POST',
		 data:{
			   key:key,
			 },
		 success:function(result){
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#addFormModal').modal('show');
		 }
	 });
   }
   
   function addOnDB(key) {
	 //alert(key);
	 $.ajax({
		 url:'controller/insert.php',
		 type:'POST',
		 data:$('#addFormData').serialize(),
		 success:function(result){
			 $('#getStatusModal').html(result);
			 $('#addFormModal').modal('hide');
			 $('#successMsgModal').modal('show');
		}
	 });
   }
   
   
   function editForm(id,key) {
	 //alert(key);
	 $.ajax({
		 url:'modal/editModal.php',
		 type:'POST',
		 data:{
			   id:id,
			   key:key,
			 },
		 success:function(result){
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#editFormModal').modal('show');
		 }
	 });
   }
   
   function updateOnDB(key) {
	 //alert(key);
	 $.ajax({
		 url:'controller/update.php',
		 type:'POST',
		 data:$('#editFormData').serialize(),
		 success:function(result){
			 $('#getStatusModal').html(result);
			 $('#editFormModal').modal('hide');
			 $('#successMsgModal').modal('show');
		}
	 });
   }
   
   function resetPassword() {
	 //alert(key);
	 $.ajax({
		 url:'controller/changePassword.php',
		 type:'POST',
		 data:$('#resetPassword').serialize(),
		 success:function(result){
			 $('#getStatusModal').html(result);
			 $('#editFormModal').modal('hide');
			 $('#successMsgModal').modal('show');
		}
	 });
   }
   
   
   function updateStatusOnDB(id,key,status) {
	 //alert(id+key+status);
	 $.ajax({
		 url:'controller/status.php',
		 type:'POST',
		 data:{
			 id:id,
			 key:key,
			 status:status,
		 },
		 success:function(result){
			 location.reload();
		}
	 });
   }
   

   
   function deleteAlert(id,name,key) {
		 //document.getElementById("primary_key_delete").setAttribute('value',id);
		 //alert(id + name + key);
		 $.ajax({
		 url:'modal/deleteModal.php',
		 type:'POST',
		 data:{
			   id:id,
			   name:name,
			   key:key,
			 },
		 success:function(result){
			 $('#getFormModal').html(result);
			 $('#successMsgModal').modal('hide');
			 $('#addFormModal').modal('show');
		 }
	   });
     }
	 
    
	function deleteOnDB(id,key){
		 //alert(id + key);
		 $.ajax({
		 url:'controller/delete.php',
		 type:'POST',
		 data:{
			   id:id,
			   key:key,
			 },
		 success:function(result){
			 $('#getStatusModal').html(result);
			 $('#addFormModal').modal('hide');
			 $('#successMsgModal').modal('show');
		 }
	   });
     }
	 
	function getServer(key, owner) {
	 //alert(key);
	 $.ajax({
		 url:'modal/serverModal.php',
		 type:'POST',
		 data:{
			   key:key,
			   owner:owner,
			 },
		 success:function(result){
			 $('#getServerModal').html(result);
			 $('#getserverPerOwner').modal('show');
		 }
	 });
   }
   
   
   function getConnection(key, role) {
	 //alert(key);
	 $.ajax({
		 url:'modal/connectionModal.php',
		 type:'POST',
		 data:{
			   key:key,
			   role:role,
			 },
		 success:function(result){
			 $('#getConnectionModal').html(result);
			 $('#getconnectionPerRole').modal('show');
		 }
	 });
   }
   
   function getUser(key, server) {
	 //alert(key);
	 $.ajax({
		 url:'modal/userModal.php',
		 type:'POST',
		 data:{
			   key:key,
			   server:server,
			 },
		 success:function(result){
			 $('#getUserModal').html(result);
			 $('#getUserPerServer').modal('show');
		 }
	 });
   }
	 
	function reload(){
		 $('.modal').modal('hide');
		 location.reload();
	 }

</script>