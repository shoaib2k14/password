<!doctype html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
		<meta name="generator" content="Jekyll v4.0.1">
		<link rel="icon" type="image/png" sizes="16x16" href="images/logo.png">
		<!--<title>Vodafone</title>-->
		<title><?php echo TITLE ?></title>
		
		
		<link rel="stylesheet" href="public/css/common/themify/themify-icons.css">
		<link rel="stylesheet" href="public/css/common/style.css">
		<link rel="stylesheet" href="public/css/common/custom.css">
		<link rel="stylesheet" href="public/css/common/buttons.dataTables.min.css">
		
	</head>
	
	<body class="fixed-layout skin-green-dark rmv-right-panel mini-sidebar">
      <div id="main-wrapper">
	     
		 <?php 
		   include('header.php');
	       include('sidebar.php'); 
		 ?>
	  <div class="page-wrapper">
        <div class="container-fluid">
		   <?php include('breadcrumb.php'); ?>