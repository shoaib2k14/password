<?php

include('../../dbConnection.php');


if($modalName == 'addModal'){
	$key=$_POST['key'];
}


if($modalName == 'addGrantModal'){
	$uID=$_POST['uID'];
	
	$uSql = "SELECT id,market_id from users WHERE id = $uID";
		$uResult = $conn->query($uSql);
		$uData = $uResult->fetch_assoc();
		$uMID = $uData['market_id'];
		
	$rSql = "SELECT id,role from roles WHERE market_id = $uMID";
		$rResult = $conn->query($rSql);
		//$Data = $rResult->fetch_assoc();
}


if($modalName == 'addServerModal'){
	$rID=$_POST['rID'];
	
	$rSql = "SELECT id,market_id from roles WHERE id = $rID";
		$rResult = $conn->query($rSql);
		$rData = $rResult->fetch_assoc();
		$rMID = $rData['market_id'];
		
	$sSql = "SELECT id,host_name from servers WHERE market_id = $rMID";
		$sResult = $conn->query($sSql);
		//$Data = $rResult->fetch_assoc();
}


if($modalName == 'addServerUserModal'){
	$sID=$_POST['sID'];
	
	$sSql = "SELECT id,market_id from servers WHERE id = $sID";
		$sResult = $conn->query($sSql);
		$sData = $sResult->fetch_assoc();
		$sMID = $sData['market_id'];
}


if($modalName == 'editModal'){
	
	switch($_REQUEST['key']) {
	  case "dR":
		$key = 'editRole';
		$sql = "SELECT * from roles WHERE id = {$_REQUEST['id']}";
		$result = $conn->query($sql);
		$data = $result->fetch_assoc();
		break;
	  case "dU":
		$key = 'editUser';
		$sql = "SELECT * from users WHERE id = {$_REQUEST['id']}";
		$result = $conn->query($sql);
		$data = $result->fetch_assoc();
		
		$mSql = "SELECT * from markets";
		$mResult = $conn->query($mSql);
		break;
	  case "dA":
		$key = 'editAdmin';
		$sql = "SELECT * from admins WHERE id = {$_REQUEST['id']}";
		$result = $conn->query($sql);
		$data = $result->fetch_assoc();
		break;
	  case "dM":
		$key = 'editMarket';
		$sql = "SELECT * from markets WHERE id = {$_REQUEST['id']}";
		$result = $conn->query($sql);
		$data = $result->fetch_assoc();
		break;
	  case "dO":
		$key = 'editOwner';
		$sql = "SELECT * from server_owners WHERE id = {$_REQUEST['id']}";
		$result = $conn->query($sql);
		$data = $result->fetch_assoc();
		break;
	  case "dS":
		$key = 'editServer';
		$sql = "SELECT * from servers WHERE id = {$_REQUEST['id']}";
		$result = $conn->query($sql);
		$data = $result->fetch_assoc();
		
		$oSql = "SELECT * from server_owners";
		$oResult = $conn->query($oSql);
		break;
	  default:
		$table_name = '';
	}
}




if($modalName == 'connectionModal'){
	
	$rID=$_POST['key'];
	$role=$_POST['role'];

    $sql = "select *,servers.status as status, servers.created_at as created_at  from servers,server_users,server_owners,roles,connects,markets WHERE connects.server_id = servers.id AND servers.id = server_users.server_id AND server_owners.id = servers.owner_id AND connects.role_id = roles.id AND roles.id = $rID AND markets.id = connects.market_id";
		$result = mysqli_query($conn,$sql);
}


if($modalName == 'serverModal'){

	$oID=$_POST['key'];
	$owner=$_POST['owner'];

	$sql = "select *,servers.status as status, servers.created_at as created_at  from servers,server_users,server_owners,markets WHERE servers.id = server_users.server_id AND server_owners.id = servers.owner_id AND server_owners.id = $oID AND servers.market_id = markets.id";
		$result = mysqli_query($conn,$sql);
		
}


if($modalName == 'grantModal'){

	$uID=$_POST['key'];
	$user=$_POST['user'];
	
	$sql = "SELECT roles.id, roles.role, grants.created_at, grants.status FROM grants,roles WHERE grants.role_id = roles.id AND grants.user_id = $uID";
		$result = mysqli_query($conn,$sql);
		
}


if($modalName == 'userModal'){

	$sID=$_POST['key'];
	$server=$_POST['server'];

	$sql = "select server_users.id, server_users.user, server_users.created_at, server_users.status from servers,server_users WHERE servers.id = server_users.server_id AND servers.id = $sID";
		$result = mysqli_query($conn,$sql);
			
}

?>