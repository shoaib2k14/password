<?php

header('Acess-Control-Allow-Origin: *');
header('Acess-Control-Allow-Credentials: true');
header('Acess-Control-Allow-Methods: GET,POST,OPTIONS');
header('Acess-Control-Allow-Headers: *');
header('Content-Type:application/json');

$data = json_decode(file_get_contents("php://input"),true);
$user_name = isset($data['userName']) ? $data['userName'] : $_REQUEST['userName'];
$key = isset($data['key']) ? $data['key'] : $_REQUEST['key'];

//$server_name = isset($data['server_name']) ? $data['server_name'] : 'aierac01r';
//$server_name = $_SERVER['SERVER_NAME'];
//$server_address = $_SERVER['SERVER_ADDR'];



include('../dbConnection.php');


$uSql = "SELECT * FROM server_users WHERE user = '$user_name' AND secure_key = '$key'";
$uResult = mysqli_query($conn,$uSql);
$uRow = mysqli_fetch_assoc($uResult);

   if(!$uRow){
		echo json_encode(
		 array(
			'result'=> "failed",
			'message'=> "Please verify your user name and key",
			'status'=> 400
			));
		 exit;
	}

$dbPassword = decrypt($uRow['password'],$uRow['secure_key']);
$inputPassword = decrypt($uRow['password'],$key);

	if($dbPassword!=$inputPassword){
		echo json_encode(
		 array(
			'result'=> "failed",
			'message'=> "Please verify your user name and key",
			'status'=> 400
			));
		 exit;
	}


$sql = "SELECT servers.password, servers.secure_key, servers.host_name, server_users.user, users.email, markets.market 
        FROM server_users,servers,users,markets 
		Where server_users.user = '$user_name' 
		AND server_users.server_id = servers.id 
		AND server_users.user_id = users.id 
		AND servers.market_id = markets.id";
$result = mysqli_query($conn,$sql);
$output = mysqli_fetch_assoc($result);
   
    if(!isset($output)){
	   echo json_encode(
	             array(
				    'result'=> "failed",
				    'message'=> "validation false",
				    'status'=> 400
					));
		exit;
    }
	$password = decrypt($output['password'],$output['secure_key']);
	//echo utf8_encode($password);
	$plaintext = preg_replace('/[���扟]/', '!#Error#!', $password);
    
	if(substr_count($plaintext, '!#Error#!') >= 1){
		echo json_encode(
	             array(
				    'result'=> "failed",
				    'message'=> "error in code please once verify your key",
				    'status'=> 400
					));
		exit;
	}
   
   echo json_encode(
		   array(
			'user_name' => $output['user'],
			'server_name'=> $output['host_name'],
			'password'=> $password,
			'market'=> $output['market'],
			'result'=> "success",
			'message'=> "validation true",
			'status'=> 200
		));



function decrypt($message,$encryption_key){
	$key = $encryption_key;
	$message = base64_decode(urldecode($message));
	$nonceSize = openssl_cipher_iv_length('aes-256-ctr');
	$nonce = mb_substr($message, 0, $nonceSize, '8bit');
	$ciphertext = mb_substr($message, $nonceSize, null, '8bit');

	$plaintext= openssl_decrypt(
	  $ciphertext, 
	  'aes-256-ctr', 
	  $key,
	  OPENSSL_RAW_DATA,
	  $nonce
	);
	
  return $plaintext;
}

?>