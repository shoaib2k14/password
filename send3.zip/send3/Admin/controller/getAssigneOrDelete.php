<?php

include('../../dbConnection.php');


if($_REQUEST['key'] == 'Grant'){

    $uID = $_REQUEST['id'];
	
	$uSql = "SELECT id,market_id from users WHERE id = $uID";
		$uResult = $conn->query($uSql);
		$uData = $uResult->fetch_assoc();
		$uMID = $uData['market_id'];
		
	$rSql = "SELECT id,role from roles WHERE market_id = $uMID";
		$rResult = $conn->query($rSql);
		//$Data = $rResult->fetch_assoc();
}



if($_REQUEST['key'] == 'Connect'){
	
	$rID = $_REQUEST['id'];
	
	$rSql = "SELECT id,market_id from roles WHERE id = $rID";
		$rResult = $conn->query($rSql);
		$rData = $rResult->fetch_assoc();
		$rMID = $rData['market_id'];
		
	$sSql = "SELECT id,host_name from servers WHERE market_id = $rMID";
		$sResult = $conn->query($sSql);
		//$Data = $rResult->fetch_assoc();
}


if($_REQUEST['key'] == 'ServerUser'){

    $sID = $_REQUEST['id'];
	
	$SqlServer = "SELECT * FROM servers WHERE market_id = 1";
		$sResult = $conn->query($SqlServer);
		//$sData = $sResult->fetch_assoc();
		
	$SqlUser = "SELECT * FROM users WHERE market_id = 1";
		$uResult = $conn->query($SqlUser);
		//$uData = $uResult->fetch_assoc();
}

?>