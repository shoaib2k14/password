<?php
define('TITLE', 'My Profile');
define('PAGE', 'profile');

include('controller/include.php');

?>

<div class="col-sm-6 mb-5">
  <div class="card mt-5 mx-5">
   <div class="card-header">Profile</div>
   <div class="card-body">
	   <h5 class="card-title text-capitalize"><?=$uFName.' '.$uLName; ?></h5>
	   <h6 class="card-text"><?=$uEmail; ?></h6>
	   <p class="card-text text-capitalize"><?=$uGender; ?></p>
	   <p class="card-text"><?=$uMobile; ?></p>
	   <p class="card-text">Market: <span class="text-uppercase"><?=$mMarket; ?></span></p>
	   <p class="card-text">Assigned At: <?=date("d-M-Y",strtotime($uCA)); ?></p>
	   <div class="float-right">
	   <button class="btn btn-danger mr-3" onclick="show()">View</button>
	   <button class="btn btn-secondary" onclick="hide()">Close</button>
	   </div>
   </div>
   </div>  
</div>

<?php 
  include('profile_view.php');
  include('layout/footer.php'); 
  $conn->close();
?>