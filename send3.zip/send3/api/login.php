<?php

header('Acess-Control-Allow-Origin: *');
header('Acess-Control-Allow-Credentials: true');
header('Acess-Control-Allow-Methods: GET,POST,OPTIONS');
header('Acess-Control-Allow-Headers: *');
header('Content-Type:application/json');

require('../php-jwt/src/BeforeValidException.php');
require('../php-jwt/src/ExpiredException.php');
require('../php-jwt/src/JWT.php');
require('../php-jwt/src/JWK.php');
require('../php-jwt/src/Key.php');
require('../php-jwt/src/SignatureInvalidException.php');

use Firebase\JWT\JWT;
use Firebase\JWT\Key;


$key = 'test';
$payload = [
    'id' => 1,
    'name' => 'shoaib raafey',
    'email' => 'shoaib.akhtar@vodafone.com'
];


$jwt = JWT::encode($payload, $key, 'HS256');
$decoded = JWT::decode($jwt, new Key($key, 'HS256'));

//print_r($jwt);

$headers = getallheaders();
$authcode = trim($headers['Authorization']);
$token = substr($authcode,7);
$key = 'test';


try{
	$decoded = JWT::decode($jwt, new Key($key, 'HS256'));
	$arr = ['msg'=>'Access Allowed', 'status'=>200, 'Data'=>$decoded];
	echo json_encode($arr);
}
catch(Exception $e){
	$arr = ['msg'=>'Access Denied', 'status'=>400, 'Data'=>$e->getMessage()];
	echo json_encode($arr);
}

/* $decoded_array = (array) $decoded;

JWT::$leeway = 60; // $leeway in seconds
$decoded = JWT::decode($jwt, new Key($key, 'HS256')); */
 


/* include('../dbConnection.php');

$sql = "select * from users";
$result = mysqli_query($conn,$sql);
$count = mysqli_num_rows($result);

if($count>0){
	while($row = mysqli_fetch_assoc($result)){
		$arr[] = $row;
	}
	echo json_encode(['status'=>'true', 'data'=>$arr, 'result'=>'true']);
}
else{
	echo json_encode(['status'=>'true', 'data'=>'No record found', 'result'=>'false']);
} */

?>