<?php
include('../../dbConnection.php');


if($_REQUEST['key']=='insertAdmin'){
	
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['mobile'] == '') || !isset($_REQUEST['status']) || !isset($_REQUEST['market'])){
		
		$myObj = new stdClass();
		$myObj->f_name = $_REQUEST['f_name']=='' ? "First name is required" : "";
		$myObj->l_name = $_REQUEST['l_name']=='' ? "Last name is required" : "";
		$myObj->email =  $_REQUEST['email']==''  ? "Email is required" : "";
		$myObj->mobile = $_REQUEST['mobile']=='' ? "Mobile is required" : "";
		$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$mobile = $_REQUEST['mobile'];
		$pass = rand (100,999);
		$status = $_REQUEST['status'];
		$market = $_REQUEST['market'];
		
		
		$myObj = new stdClass();
		
		$sql_check_email = "SELECT email FROM admins WHERE email = '$email'";
		 $result_check_email = $conn->query($sql_check_email);
		 $myObj->email = mysqli_num_rows($result_check_email)>=1 ? "This email is already exist" : "";
		 
		$sql_check_mobile = "SELECT mobile FROM admins WHERE mobile = '$mobile'";
		 $result_check_mobile = $conn->query($sql_check_mobile);
		 $myObj->mobile = mysqli_num_rows($result_check_mobile)>=1 ? "This mobile is already exist" : "";
		 
		 if($myObj->mobile != '' || $myObj->email != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "INSERT INTO admins (f_name, l_name, email, mobile, password, market_id, status) VALUES('$f_name', '$l_name', '$email', '$mobile', '$pass', $market, '$status')";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 



if($_REQUEST['key']=='insertRole'){
	
	if(($_REQUEST['role'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->role = $_REQUEST['role']=='' ? "Role is required" : "";
		//$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$role = $_REQUEST['role'];
		$market = 1;
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_role = "SELECT role FROM roles WHERE role = '$role' AND market_id = '$market'";
		 $result_check_role = $conn->query($sql_check_role);
		 $myObj->role = mysqli_num_rows($result_check_role)>=1 ? "This Role is already exist" : "";
		 
		if($myObj->role != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "INSERT INTO roles (role, market_id, status) VALUES('$role', $market, '$status')";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 



if($_REQUEST['key']=='insertGrant'){
	
	if(!isset($_REQUEST['role']) || ($_REQUEST['uID'] == '') || ($_REQUEST['uMID'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->role = !isset($_REQUEST['role'])? "Role is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$user_id = $_REQUEST['uID'];
		$market_id = $_REQUEST['uMID'];
		$role_id = $_REQUEST['role'];
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_grant = "SELECT * FROM grants WHERE user_id = $user_id AND market_id = $market_id AND role_id = $role_id";
		 $result_check_grant = $conn->query($sql_check_grant);
		 $myObj->role = mysqli_num_rows($result_check_grant)>=1 ? "This Role is already assigned to this user" : "";
		 
		if($myObj->role != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO grants (user_id, role_id, market_id, status) VALUES($user_id, $role_id, $market_id, $status)";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	 $conn->close();
	}
} 




if($_REQUEST['key']=='insertConnects'){
	
	if(!isset($_REQUEST['server']) || ($_REQUEST['rID'] == '') || ($_REQUEST['rMID'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->host = !isset($_REQUEST['server'])? "Server is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$role_id = $_REQUEST['rID'];
		$market_id = $_REQUEST['rMID'];
		$server_id = $_REQUEST['server'];
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_connects = "SELECT * FROM connects WHERE role_id = $role_id AND market_id = $market_id AND server_id = $server_id";
		 $result_check_connects = $conn->query($sql_check_connects);
		 $myObj->host = mysqli_num_rows($result_check_connects)>=1 ? "This Server is already assigned to this role" : "";
		 
		if($myObj->host != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO connects (role_id, server_id, market_id, status) VALUES($role_id, $server_id, $market_id, $status)";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 


if($_REQUEST['key']=='insertServerUser'){
	
	if(($_REQUEST['user'] == '') || ($_REQUEST['sID'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->user = $_REQUEST['user'] == '' ? "User is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$server_id = $_REQUEST['sID'];
		$user = $_REQUEST['user'];
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_users = "SELECT * FROM server_users WHERE user = '$user' AND server_id = $server_id";
		 $result_check_users = $conn->query($sql_check_users);
		 $myObj->user = mysqli_num_rows($result_check_users)>=1 ? "This User is already exists to this Server" : "";
		 
		if($myObj->user != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
	    $sql = "INSERT INTO server_users (user, server_id, status) VALUES('$user', $server_id, $status)";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 



if($_REQUEST['key']=='insertMarket'){
	
	if(($_REQUEST['market'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->market = $_REQUEST['market']=='' ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$market = $_REQUEST['market'];
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_market = "SELECT market FROM markets WHERE market = '$market'";
		 $result_check_market = $conn->query($sql_check_market);
		 $myObj->market = mysqli_num_rows($result_check_market)>=1 ? "This Market is already exist" : "";
		 
		if($myObj->market != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "INSERT INTO markets (market, status) VALUES('$market', '$status')";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	 $conn->close();
	}
} 



if($_REQUEST['key']=='insertOwner'){
	
	if(($_REQUEST['owner'] == '') || ($_REQUEST['email'] == '') || !isset($_REQUEST['market']) || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->owner = $_REQUEST['owner']=='' ? "Owner name is required" : "";
		$myObj->email =  $_REQUEST['email']==''  ? "Email is required" : "";
		$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$owner = $_REQUEST['owner'];
		$email = $_REQUEST['email'];
		$market = $_REQUEST['market'];
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_email = "SELECT email FROM server_owners WHERE email = '$email'";
		 $result_check_email = $conn->query($sql_check_email);
		 $myObj->email = mysqli_num_rows($result_check_email)>=1 ? "This Email is already exist" : "";
		 
		if($myObj->email != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "INSERT INTO server_owners (owner, email, market_id, status) VALUES('$owner', '$email', $market, '$status')";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 


if($_REQUEST['key']=='insertServer'){
	
	if(($_REQUEST['ticket'] == '') || ($_REQUEST['host'] == '') || !isset($_REQUEST['os_type']) || ($_REQUEST['ip'] == '') || ($_REQUEST['password'] == '') || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->host = $_REQUEST['host']=='' ? "Host name is required" : "";
		$myObj->os_type =  $_REQUEST['os_type']==''  ? "Os Type is required" : "";
		$myObj->ip =  $_REQUEST['ip']==''  ? "Ip is required" : "";
		//$myObj->port =  $_REQUEST['port']==''  ? "Port is required" : "";
		$myObj->password =  $_REQUEST['password']==''  ? "Password is required" : "";
		//$myObj->owner = !isset($_REQUEST['owner']) ? "Owner is required" : "";
		//$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		//$owner_id = $_REQUEST['owner'];
		$host = $_REQUEST['host'];
		$ip = $_REQUEST['ip'];
		//$port = $_REQUEST['port'];
		$os_type = $_REQUEST['os_type'];
		$password = $_REQUEST['password'];
		$market = 1;
		$status = $_REQUEST['status'];
		
		$myObj = new stdClass();
		
		$sql_check_host = "SELECT host_name FROM servers WHERE host_name = '$host'";
		 $result_check_host = $conn->query($sql_check_host);
		 $myObj->host = mysqli_num_rows($result_check_host)>=1 ? "This Server name is already exist" : "";
		 
		$sql_check_ip = "SELECT ip_address FROM servers WHERE ip_address = '$ip'";
		 $result_check_ip = $conn->query($sql_check_ip);
		 $myObj->ip = mysqli_num_rows($result_check_ip)>=1 ? "This IP adderss is already exist" : "";
		 
		 if($myObj->host != '' || $myObj->ip != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		
		$sql = "INSERT INTO servers (host_name, ip_address, os_type, password, market_id, status) VALUES('$host', '$ip', '$os_type', '$password', $market, '$status')";
		
		if($conn->query($sql) === TRUE) {
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
	  $conn->close();
	}
} 



if($_REQUEST['key']=='insertUser'){
	
	if(($_REQUEST['ticket'] == '') || ($_REQUEST['unix_id'] == '') || ($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['mobile'] == '') || !isset($_REQUEST['gender']) || !isset($_REQUEST['status'])){
		
		$myObj = new stdClass();
		$myObj->ticket =  $_REQUEST['ticket']=='' ? "Ticket No. is required" : "";
		$myObj->unix =  $_REQUEST['unix_id']=='' ? "Unix Id is required" : "";
		$myObj->f_name = $_REQUEST['f_name']=='' ? "First name is required" : "";
		$myObj->l_name =  $_REQUEST['l_name']=='' ? "Last Name is required" : "";
		$myObj->email = $_REQUEST['email']=='' ? "Email is required" : "";
		$myObj->mobile = !isset($_REQUEST['mobile']) ? "Mobile is required" : "";
		//$myObj->market = !isset($_REQUEST['market']) ? "Market is required" : "";
		$myObj->status = !isset($_REQUEST['status']) ? "Status is required" : "";
		$myObj->gender = !isset($_REQUEST['gender']) ? "Gender is required" : "";
		$myObj->code = 202;
		$myJSON = json_encode($myObj);
		echo $myJSON;
		die();
	}
	else{
		$ticket = $_REQUEST['ticket'];
		$unix_id = $_REQUEST['unix_id'];
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$mobile = $_REQUEST['mobile'];
		$market_id = 1;
		$status = $_REQUEST['status'];
		$gender = $_REQUEST['gender'];
		$password = rand (100,999);
		
		
		$myObj = new stdClass();
		
		$sql_check_email = "SELECT email FROM users WHERE email = '$email'";
		 $result_check_email = $conn->query($sql_check_email);
		 $myObj->email = mysqli_num_rows($result_check_email)>=1 ? "This email is already exist" : "";
		 
		$sql_check_mobile = "SELECT mobile FROM users WHERE mobile = '$mobile'";
		 $result_check_mobile = $conn->query($sql_check_mobile);
		 $myObj->mobile = mysqli_num_rows($result_check_mobile)>=1 ? "This mobile is already exist" : "";
		 
		 if($myObj->mobile != '' || $myObj->email != ''){
			$myObj->code = 202;
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		 }
		
		$sql = "INSERT INTO users (unix_id, market_id, f_name, l_name, email, mobile, password, status, gender) VALUES('$unix_id', '$market_id','$f_name', '$l_name', '$email', '$mobile', '$password', '$status', '$gender')";
		
		
		if($conn->query($sql) === TRUE) {
			sendMail($f_name, $email, $password);
			$myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Added Successfully";
			$myObj->msg = "success";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
			
		} else {
		    $myObj = new stdClass();
		    $myObj->code = 200;
			$myObj->text = "Somthing Went Wrong";
			$myObj->msg = "info";
			$myJSON = json_encode($myObj);
			echo $myJSON;
			die();
		    //echo "Error: " . $sql . "<br>" . $conn->error;
		}
      $conn->close();
	}
} 


function sendMail($name, $email, $password){
	    $htmlbody = '
			 <html> 
				<body> 
					<h3 style=" text-transform:capitalize;">Hello '.$name.'</h3> 
					<p>Welcome to Vodafone!</p>
					<p>Your are successfully registerd on our password portal</p>
					<p>Please find your login credential below</p>
					<table style="text-align:left"> 
					  <tr> 
						<th>User:</th>
						<td>'.$email.'</td> 
					  </tr> 
					  <tr> 
						<th>Password:</th>
						<td>'.$password.'</td> 
					  </tr> 
					  <tr> 
						<th>Url link:</th>
						<td>
						  <a href="http://localhost:81/password/index.php">www.password-engine-vodafone.com</a>
						</td> 
					  </tr> 
					</table> 
				</body> 
			 </html>';
			 
		$subject = "Your are successfully registerd on password portal";

        require('../../phpmailer/PHPMailerAutoload.php');

		$mail = new PHPMailer;
		$mail->isSMTP();
		$mail->SMTPDebug = 0;
		$mail->Host = 'smtp.gmail.com';
		$mail->Port = 587;
		$mail->SMTPSecure = 'tls';
		$mail->SMTPAuth = true;
		$mail->Username = "sraafey2k14@gmail.com";
		$mail->Password = "hvpmuodnbtriltvv";
		$mail->setFrom("sraafey2k14@gmail.com");
		$mail->addAddress($email);

		//$mail->addAttachment($directory);
		$mail->Subject = $subject;
		$mail->msgHTML($htmlbody);
		$mail->send();
		/* if (!$mail->send()) {
            echo "Mailer Error: ".$mail->ErrorInfo;
		}
		else
		{
			echo "mail Sent Successfully";
		} */
}



/*

if(isset($_REQUEST['insert_user'])){
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['phone'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['company'] == '') || ($_REQUEST['department'] == '') || ($_REQUEST['position'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$phone = $_REQUEST['phone'];
		$mobile = $_REQUEST['mobile'];
		$company = $_REQUEST['company'];
		$department = $_REQUEST['department'];
		$position = $_REQUEST['position'];
		$date = $_REQUEST['date'];
		$status = $_REQUEST['status'];;
		
		$sql = 'INSERT INTO pwuser (FIRST_NAME, LAST_NAME, EMAIL, PHONE, MOBILE, COMPANY, DEPARTMENT, POSITION, STATUS) VALUES(:f_name, :l_name, :email, :phone, :mobile, :company, :department, :position, :status)';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':f_name', $f_name);
		oci_bind_by_name($parse, ':l_name', $l_name);
		oci_bind_by_name($parse, ':email', $email);
		oci_bind_by_name($parse, ':phone', $phone);
		oci_bind_by_name($parse, ':mobile', $mobile);
		oci_bind_by_name($parse, ':company', $company);
		oci_bind_by_name($parse, ':department', $department);
		oci_bind_by_name($parse, ':position', $position);
		//oci_bind_by_name($parse, ':date', $date);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}




if(isset($_REQUEST['insert_role'])){
	if(($_REQUEST['name'] == '') || ($_REQUEST['description'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$name = $_REQUEST['name'];
		$description = $_REQUEST['description'];
		$status = $_REQUEST['status'];
		
		$sql = 'INSERT INTO pwroles (NAME, DESCRIPTION, STATUS) VALUES(:name, :description, :status)';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':name', $name);
		oci_bind_by_name($parse, ':description', $description);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}

if(isset($_REQUEST['insert_group'])){
	if(($_REQUEST['name'] == '') || ($_REQUEST['description'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$name = $_REQUEST['name'];
		$description = $_REQUEST['description'];
		$status = $_REQUEST['status'];
		
		$sql = 'INSERT INTO pwgroups (NAME, DESCRIPTION, STATUS) VALUES(:name, :description, :status)';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':name', $name);
		oci_bind_by_name($parse, ':description', $description);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}


if(isset($_REQUEST['insert_connection'])){
	if(($_REQUEST['system'] == '') || ($_REQUEST['user'] == '') || ($_REQUEST['password'] == '') || ($_REQUEST['category'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$system = $_REQUEST['system'];
		$user = $_REQUEST['user'];
		$password = $_REQUEST['password'];
		$category = $_REQUEST['category'];
		$status = $_REQUEST['status'];
		
		$sql = 'INSERT INTO pwconnects (SYSTEM, CONNECT_USER, CONNECT_PASSWORD, CATEGORY, STATUS) VALUES(:system, :user, :password, :category, :status)';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':system', $system);
		oci_bind_by_name($parse, ':user', $user);
		oci_bind_by_name($parse, ':password', $password);
		oci_bind_by_name($parse, ':category', $category);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}


if($msg == 1){
$myObj = new stdClass();
$myObj->msg = '
			 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
				<div class="modal-dialog modal-dialog-centered">
					<div class="modal-content">
					   <div class="modal-body text-center">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<img src="assets/img/sent.png" alt="" width="50" height="46">
							<h3 class="delete_class">Please fill all the fields</h3>
							<div class="m-t-20"> 
								<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
							</div>
						</div>
					</div>
				</div>
			</div>';
			
$myObj->code = 200;
$myJSON = json_encode($myObj);
echo $myJSON;
die();
}


if($msg == 2){
$myObj = new stdClass();
$myObj->msg = '
	 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal" onclick="reload()">&times;</button>
					<img src="assets/img/sent.png" alt="" width="50" height="46">
					<h3 class="delete_class">Inserted Successfully</h3>
					<div class="m-t-20">
						<a href="#" class="btn btn-white" data-dismiss="modal" onclick="reload()">Close</a>
					</div>
				</div>
			</div>
		</div>
	</div>';
$myObj->code = 200;
$myJSON = json_encode($myObj);
echo $myJSON;
die();
}


if($msg == 3){
$myObj = new stdClass();
$myObj->msg = '
	 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<img src="assets/img/sent.png" alt="" width="50" height="46">
					<h3 class="delete_class">Somthing Went Wrong</h3>
					<div class="m-t-20"> 
						<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
					</div>
				</div>
			</div>
		</div>
	</div>';
$myObj->code = 200;
$myJSON = json_encode($myObj);
echo $myJSON;
die();
}




if($msg == 4){
$myObj = new stdClass();
$myObj->msg = '
	 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body text-center">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<img src="assets/img/sent.png" alt="" width="50" height="46">
					<h3 class="delete_class">Undefined error please try after some time</h3>
					<div class="m-t-20"> 
						<a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
					</div>
				</div>
			</div>
		</div>
	</div>';
$myObj->code = 200;
$myJSON = json_encode($myObj);
echo $myJSON;
die(); 
}

*/
?>

<!--<button class="btn btn-primary veiwbutton " onclick="addAdmin('addAdmin')">Add Admin</button>-->

