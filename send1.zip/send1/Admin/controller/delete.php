<?php

include('../../dbConnection.php');

$msg = 0;

switch($_REQUEST['key']) {
  case "dR":
    $table_name = 'roles';
    break;
  case "dU":
    $table_name = 'users';
    break;
  case "dA":
    $table_name = 'admins';
    break;
  case "dM":
    $table_name = 'markets';
    break;
  case "dO":
    $table_name = 'server_owners';
    break;
  case "dS":
    $table_name = 'servers';
    break;
  default:
    $table_name = '';
}



if(isset($table_name)){
	
	$sql = "DELETE FROM $table_name WHERE id = {$_REQUEST['id']}";
	
	if($conn->query($sql) === TRUE){
	    $msg = 1;
	}
	else{
		$msg = 0;
		//echo "Error: " . $sql . "<br>" . $conn->error;
	}
}



/*
if(isset($_REQUEST['delete'])){
	
		$id = $_REQUEST['id'];
		
		$sql = 'DELETE FROM '.$table_name.' WHERE ID=:id';
		
		$parse = oci_parse($conn, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Deleted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
}
*/

?>



<?php
if($msg == 1){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal" onclick="reload()">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Deleted Successfully</h3>
				<div class="m-t-20"> 
				    <a href="#" class="btn btn-white" data-dismiss="modal" onclick="reload()">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>




<?php
if($msg == 0){?>
 <div id="successMsgModal" class="modal fade delete-modal" role="dialog">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
		   <div class="modal-body text-center">
			    <button type="button" class="close" data-dismiss="modal">&times;</button>
				<img src="assets/img/sent.png" alt="" width="50" height="46">
				<h3 class="delete_class">Unable to delete</h3>
				<div class="m-t-20"> 
				    <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } ?>