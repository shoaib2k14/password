<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>Vodafone Password Engine</title>

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">

	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/plugins/datatables/datatables.min.css">
	<!-- Feathericon CSS -->
	<link rel="stylesheet" href="assets/css/feathericon.min.css">

	<link rel="stylesheet" href="assets/plugins/morris/morris.css">

	<!-- Main CSS -->
	<link rel="stylesheet" href="assets/css/style.css">
	
	<style>
	#delete_asset form{
		display:inline-block;
	}
	.form-group {
		margin-bottom: 0rem;
		margin-top: 1rem;
    }
	.modal-body {
		padding: 1rem 2rem;
	}
	
	</style>

</head>

<body>
	<!-- Main Wrapper -->
	<div class="main-wrapper">
	
	   <?php include("includes/topbar.php"); ?>
	   
		<?php include("includes/sidebar.php"); ?>