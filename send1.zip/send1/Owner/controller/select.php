<?php

include('../dbConnection.php');

if(!isset($_SESSION['is_owner_login'])){
	echo "<script> location.href='index.php'; </script>";
 }
 
$oMarket = $_SESSION['oMarket'];
$oEmail = $_SESSION['oEmail']; 
 
$oSql = "SELECT * from server_owners WHERE email = '$oEmail'";
$oResult = mysqli_query($conn, $oSql);
$oRow = mysqli_fetch_assoc($oResult);
$oID = $oRow['id'];
$oOwner = $oRow['owner'];




	$admin = $oOwner;
	
	if($table_name == 'dashboard'){
		
		// I'm India so my timezone is Asia/Calcutta
			 date_default_timezone_set('Asia/Calcutta');

		 // 24-hour format of an hour without leading zeros (0 through 23)
			 $Hour = date('G');

			if ( $Hour >= 5 && $Hour <= 11 ) {
				$grettings = "Good Morning";
			} else if ( $Hour >= 12 && $Hour <= 17 ) {
				$grettings = "Good Afternoon";
			} else if ( $Hour >= 15 || $Hour <= 4 ) {
				$grettings = "Good Evening";
			}
			
		  $sql_server = "SELECT count(*) as server FROM servers WHERE owner_id = $oID AND market_id = $oMarket";
			 $result_server = $conn->query($sql_server);
			 $row_server = mysqli_fetch_array($result_server);
			 $total_servers = $row_server['server'];

          
		  $sql_users = "SELECT count(*) as users FROM servers, server_users WHERE servers.id = server_users.server_id AND servers.owner_id = $oID AND servers.market_id = $oMarket";
			 $result_users = $conn->query($sql_users);
			 $row_users = mysqli_fetch_array($result_users);
			 $total_users = $row_users['users'];
			 
	}
	
	
	
	if($table_name == 'servers'){
		$sql = "select *,servers.id AS id, servers.status AS status, servers.created_at AS created_at FROM servers,server_owners,markets WHERE server_owners.id = servers.owner_id AND servers.market_id = markets.id AND server_owners.market_id = $oMarket";
	}
	
	if($table_name == 'changePassword'){
		$sql = "select * FROM servers WHERE owner_id = $oID AND market_id = $oMarket";
	}
	
	


/*** For oracle ***/
	//$result = oci_parse($connection, $sql);
	//oci_execute($result);

/*** For mysql ***/
  if($table_name != 'dashboard'){
	$result = mysqli_query($conn,$sql);
  }
	//$count = mysqli_num_rows($result);
	
	
 

?>