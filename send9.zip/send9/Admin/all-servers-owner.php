<?php
$table_name = "server_owners";
$alert = "";

include('controller/select.php');
include("includes/header.php");

?>


<div class="page-wrapper">
	<div class="content container-fluid">
	   
	   <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Server Users</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Server Users</li>
					</ol>
					<button class="btn btn-danger float-right veiwbutton ml-3" onclick="AddOrDeleteServerUserForm('ServerUser')">Add / Remove User</button>
					<button class="btn btn-danger float-right veiwbutton ml-3" onclick="AddOrDeleteServerUserForm('AddServerUser')">Add Service / Functional Account</button>
				</div>
			</div>
		</div>
	
		<div class="page-header">
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					<div class="card-body booking_card">
						<div class="table-responsive">
							<table class="datatable table table-stripped table table-hover table-center mb-0">
								<thead>
									<tr>
										<th>#</th>
										<th>Server User</th>
										<th>Server Owner</th>
										<th>Server Name</th>
										<th>Market</th>
										<th>Status</th>
										<th>Created On</th>
										<!--<th>View</th>-->
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tbody>
								 <?php
								  foreach( $result as $key=>$row ){ ?>
									<tr>
										<td><?=++$key?></td>
										<td><?=$row["user"]?></td>
										<td>
										   <h6 class="text-capitalize font-weight-light m-0"><?=$row["f_name"]." ".$row["l_name"]?></h6>
										   <?=$row["email"];?>
										</td>
										<td><?=$row["host_name"]?></td>
										<td class="text-capitalize"><?=$row["market"]?></td>
										<!--
										<td>
										   <button type="submit" class="btn btn-status <?php echo $row["status"] == 1 ? 'btn-success' : 'btn-secondary' ?>" onclick="updateStatusOnDB('<?=$row["id"]?>','dO','<?=$row["status"]?>')">
											   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
										   </button>
										</td>
										-->
										
										<td>
										 <?php 
										   if($row["status"] == 0) 
											     echo '<button class="btn btn-warning btn-status">Pending</button>';
										   
										   if($row["status"] == 1) 
											     echo '<button class="btn btn-success btn-status">Active</button>';
										   
										   if($row["status"] == 2) 
											     echo '<button class="btn btn-danger btn-status">Declined</button>';
										 ?>
									    </td>
										
										<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
										<!--
										<td>
											<button class="btn btn-warning" onclick="getServer('<?=$row["id"]?>', '<?=$row["owner"]?>')"><i class="fa fa-eye"></i></button>
										</td>
										-->
										<td class="text-right">
											<div class="dropdown dropdown-action d-inline">
											  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											   <i class="fa fa-ellipsis-v ellipse_color"></i>
											  </a>
											  
											  <div class="dropdown-menu dropdown-menu-right">
												  
												  <button class="dropdown-item" onclick="editForm('<?=$row["id"]?>','dO')">
													<i class="fa fa-pencil-square-o m-r-5 text-primary"></i> Edit User 
												  </button>
												  
												  <button class="dropdown-item" data-toggle="modal" data-target="#delete_asset" onclick="deleteOnDB('<?=$row["id"]?>','<?=$row["user"]?>','dSU')">
												   <i class="fa fa-trash-o m-r-5 text-danger"></i> Delete User
												  </button>
											   </div>
											  </div>
										 </td>
									 </tr>
								   <?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			 </div>
		  </div>
	   </div>
    </div>
</div>
	
	
	
<!-- Modal's -->
 <div id="getServerModal"></div>
 <div id="getFormModal"></div>
 <div id="getStatusModal"></div>
<!-- Model's -->
	
	
	
<!-- jQuery -->
<script>
	var element = document.getElementById("ServerUser");
	   element.classList.add("active");
</script>
<?php include("includes/footer.php"); ?>
	