<?php

include('../dbConnection.php');


if(!isset($_SESSION['is_admin_login'])){
	echo "<script> location.href='index.php'; </script>";
 }
else{
	 $aEmail =  $_SESSION['aEmail'];
	 
	 $adminSql = "SELECT * FROM admins where email = '{$aEmail}' limit 1";
	 $adminResult = $conn->query($adminSql);
	 
	 if(mysqli_num_rows($adminResult) == 0){
		 echo "<script> location.href='../logout.php'; </script>";
	 }

	 $adminRow = $adminResult->fetch_assoc();
	 
	 $aId = $adminRow['id'];
	 $aMId = $adminRow['market_id'];
	 $aMobile = $adminRow['mobile'];
	 //$aRole = $adminRow['role'];
	 $aFName = $adminRow['f_name'];
	 $aLName = $adminRow['l_name'];
	 $aGender = $adminRow['gender'];
	 $aCA = $adminRow['created_at'];
	 $aUA = $adminRow['updated_at'];
	 
	 $aMarket = $_SESSION['aMarket'];
     $aRole = $_SESSION['aRole'];
	 
}
 


if($aRole != 0){
	
	$admin = "Admin";
	
	if($table_name == 'dashboard'){
		
		// I'm India so my timezone is Asia/Calcutta
			 date_default_timezone_set('Asia/Calcutta');

		 // 24-hour format of an hour without leading zeros (0 through 23)
			 $Hour = date('G');

			if ( $Hour >= 5 && $Hour <= 11 ) {
				$grettings = "Good Morning";
			} else if ( $Hour >= 12 && $Hour <= 17 ) {
				$grettings = "Good Afternoon";
			} else if ( $Hour >= 15 || $Hour <= 4 ) {
				$grettings = "Good Evening";
			}
			
			
		  $sql_requested = "SELECT count(*) as requested FROM role_requests where market_id = $aMarket";
			 $result_requested = $conn->query($sql_requested);
			 $row_requested = mysqli_fetch_array($result_requested);
			 $requested_roles = $row_requested['requested'];

	      $sql_connection = "SELECT count(*) as connection FROM connects where market_id = $aMarket";
			 $result_connection = $conn->query($sql_connection);
			 $row_connection = mysqli_fetch_array($result_connection);
			 $all_connections = $row_connection['connection'];

	     $sql_users = "SELECT count(*) as users FROM users where market_id = $aMarket";
			 $result_users = $conn->query($sql_users);
			 $row_users = mysqli_fetch_array($result_users);
			 $all_users = $row_users['users'];
			 
		
		$sql_roles = "SELECT count(*) as roles FROM roles where market_id = $aMarket";
			 $result_roles = $conn->query($sql_roles);
			 $row_roles = mysqli_fetch_array($result_roles);
			 $all_roles = $row_roles['roles'];
			 
		$sql_servers = "SELECT count(id) as servers FROM servers where market_id = $aMarket";
			 $result_servers = $conn->query($sql_servers);
			 $row_servers = mysqli_fetch_array($result_servers);
			 $all_servers = $row_servers['servers'];

	
	}
	
	
	if($table_name == 'users'){
		//$sql = "select * from users,user_profiles,markets,departments,positions WHERE users.id = user_profiles.user_id AND user_profiles.market_id = markets.id AND user_profiles.department_id = departments.id AND user_profiles.position_id = positions.id";
		
		$sql = "select * from markets, users WHERE users.market_id = markets.id AND users.market_id = $aMarket ORDER BY users.id Desc";
	}
	
	if($table_name == 'admins'){
		$sql = "select *, admins.id, admins.status, admins.created_at from admins,markets WHERE admins.market_id = markets.id AND admins.role = 1 AND admins.market_id = $aMarket";
	}

	if($table_name == 'roles'){
		$sql = "select *,roles.id AS id, roles.status AS status FROM roles,markets WHERE roles.market_id = markets.id AND market_id = $aMarket";
	}
    
	if($table_name == 'markets'){
		$sql = "select * FROM markets WHERE id = $aMarket";
	}
	
	if($table_name == 'servers'){
		$sql = "select *,servers.id AS id, servers.status AS status, servers.created_at AS created_at FROM servers,markets WHERE servers.market_id = markets.id AND servers.market_id = $aMarket";
	}
	
	if($table_name == 'server_owners'){
		$sql = "select *,server_users.id AS id, server_users.status AS status FROM server_users,servers,users,markets WHERE users.market_id = markets.id AND users.market_id = $aMarket AND servers.market_id = $aMarket AND server_users.user_id = users.id AND server_users.server_id = servers.id";
	}
	
	if($table_name == 'connects'){
		$sql = "select * from connects WHERE market_id = $aMarket";
	}
	
	if($table_name == 'profile'){
		$sql_market = "select market from markets WHERE id = $aMarket limit 1";
		     $result_market = $conn->query($sql_market);
			 $row_market = mysqli_fetch_array($result_market);
			 $admin_market = $row_market['market'];
	}
	
	if($table_name == 'role_requests'){
		$sql = "select *,role_requests.id AS id, role_requests.created_at AS created_at, role_requests.updated_at AS updated_at from role_requests,users,roles,markets WHERE role_requests.user_id = users.id AND role_requests.role_id = roles.id AND role_requests.market_id = markets.id AND role_requests.market_id = $aMarket";
		  $result = mysqli_query($conn,$sql);
		  $row = mysqli_fetch_assoc($result);
		
		if(isset($row)){
			if($row['is_pending']==1){ $status = 'Pending'; $btnColor = 'btn-warning'; $icon = 'fa fa-clock-o';}
	        if($row['is_approved']==1){ $status = 'Approved'; $btnColor = 'btn-success'; $icon = 'fa fa-check-square-o';}
	        if($row['is_declined']==1){ $status = 'Declined'; $btnColor = 'btn-danger'; $icon = 'fa fa-ban';}
		}  
		
     }
	 
	 if($table_name == 'passwordEncryption'){

		//$sID = $_REQUEST['id'];
		
		$SqlServer = "SELECT * FROM servers WHERE market_id = 1";
			$sResult = $conn->query($SqlServer);
			$tResult = $conn->query($SqlServer);
			
		$SqlUser = "SELECT * FROM users WHERE market_id = 1";
			$uResult = $conn->query($SqlUser);
	}
}





else{
	$admin = "Super Admin";
	
	if($table_name == 'dashboard'){
		
		// I'm India so my timezone is Asia/Calcutta
			 date_default_timezone_set('Asia/Calcutta');

		 // 24-hour format of an hour without leading zeros (0 through 23)
			 $Hour = date('G');

			if ( $Hour >= 5 && $Hour <= 11 ) {
				$grettings = "Good Morning";
			} else if ( $Hour >= 12 && $Hour <= 17 ) {
				$grettings = "Good Afternoon";
			} else if ( $Hour >= 15 || $Hour <= 4 ) {
				$grettings = "Good Evening";
			}
			
			$sql_requested = "SELECT count(id) as requested FROM role_requests";
			 $result_requested = $conn->query($sql_requested);
			 $row_requested = mysqli_fetch_array($result_requested);
			 $requested_roles = $row_requested['requested'];

	      $sql_connection = "SELECT count(*) as connection FROM connects";
			 $result_connection = $conn->query($sql_connection);
			 $row_connection = mysqli_fetch_array($result_connection);
			 $all_connections = $row_connection['connection'];

	     $sql_users = "SELECT count(id) as users FROM users";
			 $result_users = $conn->query($sql_users);
			 $row_users = mysqli_fetch_array($result_users);
			 $all_users = $row_users['users'];
			 
		
		$sql_roles = "SELECT count(id) as roles FROM roles";
			 $result_roles = $conn->query($sql_roles);
			 $row_roles = mysqli_fetch_array($result_roles);
			 $all_roles = $row_roles['roles'];
		
		
		$sql_admins = "SELECT count(id) as admins FROM admins where role = 1";
			 $result_admins = $conn->query($sql_admins);
			 $row_admins = mysqli_fetch_array($result_admins);
			 $all_admins = $row_admins['admins'];
	
	    
		$sql_markets = "SELECT count(id) as markets FROM markets";
			 $result_markets = $conn->query($sql_markets);
			 $row_markets = mysqli_fetch_array($result_markets);
			 $all_markets = $row_markets['markets'];
			 
		$sql_servers = "SELECT count(id) as servers FROM servers";
			 $result_servers = $conn->query($sql_servers);
			 $row_servers = mysqli_fetch_array($result_servers);
			 $all_servers = $row_servers['servers'];
	}
	
	if($table_name == 'users'){
		//$sql = "select * from users,user_profiles,markets,departments,positions WHERE users.id = user_profiles.user_id AND user_profiles.market_id = markets.id AND user_profiles.department_id = departments.id AND user_profiles.position_id = positions.id";
		
		$sql = "select *,users.id AS uId,users.status AS uStatus, users.created_at AS uCreatedAt from users,markets WHERE users.market_id = markets.id ORDER BY users.id Desc";
	}
	
	if($table_name == 'admins'){
		$sql = "select *, admins.id, admins.status, admins.created_at from admins,markets WHERE admins.market_id = markets.id AND admins.role = 1";
	}

	if($table_name == 'roles'){
		$sql = "select *,roles.id AS id, roles.status AS status from roles,markets WHERE roles.market_id = markets.id ORDER BY roles.id Desc";
	}
    
	if($table_name == 'markets'){
		$sql = "select * from markets";
	}
	
	if($table_name == 'servers'){
		$sql = "select *,servers.id AS id, servers.status AS status, servers.created_at AS created_at from servers,markets WHERE servers.market_id = markets.id";
	}
	
	if($table_name == 'server_owners'){
		$sql = "select *,server_owners.id AS id, server_owners.status AS status from server_owners,markets WHERE server_owners.market_id = markets.id";
	}
	
	if($table_name == 'connects'){
		$sql = "select * from connects";
	}
	
	if($table_name == 'role_requests'){
		$sql = "select * from role_requests,users,roles,markets WHERE role_requests.user_id = users.id AND role_requests.role_id = roles.id AND role_requests.market_id = markets.id";
	}
}


   


/*** For oracle ***/
	//$result = oci_parse($connection, $sql);
	//oci_execute($result);

/*** For mysql ***/
  if($table_name != 'dashboard' AND $table_name != 'profile' AND $table_name != 'passwordEncryption'){
	$result = mysqli_query($conn,$sql);
  }
	//$count = mysqli_num_rows($result);
	
	
 

?>